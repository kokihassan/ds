# ============================================================
#  لوحة تحكم الأدمن الكاملة - مع 5 إضافات جديدة
# ============================================================

from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from database import (get_all_users, get_stats, set_plan, ban_user,
                      unban_user, reset_user_usage, get_user)
import config
from config import PLANS, ADMINS
from states import set_state


# ══════════════════════════════════════════════════════════════
#  الصفحة الرئيسية
# ══════════════════════════════════════════════════════════════

def admin_home_text():
    stats   = get_stats()
    by_plan = stats["by_plan"]
    lines   = ""
    for k, p in PLANS.items():
        lines += f"  {p['name']}: **{by_plan.get(k,0)}**\n"
    maint = "🔴 وضع الصيانة مفعّل" if config.MAINTENANCE_MODE else "🟢 البوت يعمل"
    return (
        f"🛡️ **لوحة تحكم الأدمن**\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 المستخدمين: **{stats['total']}**\n"
        f"📡 نشطون اليوم: **{stats['active_today']}**\n"
        f"🚫 محظورون: **{stats['banned']}**\n"
        f"حالة البوت: {maint}\n\n"
        f"📦 **الباقات:**\n{lines}\n"
        f"اختر قسماً:"
    )

def admin_home_kb():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📊 إحصائيات",        callback_data="adm_stats"),
            InlineKeyboardButton("👥 المستخدمون",      callback_data="adm_users_0"),
        ],
        [
            InlineKeyboardButton("📦 الباقات",         callback_data="adm_plans"),
            InlineKeyboardButton("🚫 المحظورون",       callback_data="adm_banned"),
        ],
        [
            InlineKeyboardButton("📢 برودكاست",        callback_data="adm_broadcast"),
            InlineKeyboardButton("⚙️ المميزات",        callback_data="adm_features"),
        ],
        [
            InlineKeyboardButton("📝 النصوص",          callback_data="adm_texts"),
            InlineKeyboardButton("🔧 الأدمن",          callback_data="adm_admins"),
        ],
        [
            InlineKeyboardButton("💬 رسائل الدعم",     callback_data="adm_support"),
            InlineKeyboardButton("🗑️ تنظيف البيانات",  callback_data="adm_cleanup"),
        ],
        [
            InlineKeyboardButton("🔄 إعادة تشغيل",     callback_data="adm_restart"),
            InlineKeyboardButton("📋 سجل الأوامر",     callback_data="adm_logs"),
        ],
        [
            InlineKeyboardButton("🤖 إعدادات AI",      callback_data="adm_ai_settings"),
            InlineKeyboardButton("🌐 البروكسيات",      callback_data="adm_proxy_status"),
        ],
        [
            InlineKeyboardButton("📤 تصدير المستخدمين", callback_data="adm_export_users"),
            InlineKeyboardButton("🔧 الصيانة",          callback_data="adm_maintenance"),
        ],
        [
            InlineKeyboardButton("📈 إحصائيات التصدير", callback_data="adm_export_stats"),
            InlineKeyboardButton("⚡ حدود الطلبات",     callback_data="adm_rate_limits"),
        ],
        [
            InlineKeyboardButton("🎁 كود ترقية",        callback_data="adm_promo_codes"),
            InlineKeyboardButton("📣 إعلان مخصص",       callback_data="adm_custom_banner"),
        ],
    ])


# ══════════════════════════════════════════════════════════════
#  Handler رئيسي
# ══════════════════════════════════════════════════════════════

async def handle_admin_callback(bot, update, data: str):
    uid = update.from_user.id
    if uid not in config.ADMINS:
        return await update.answer("🚫 ليس لديك صلاحية", show_alert=True)
    msg = update.message

    # ── الرئيسية ──────────────────────────────────────────────
    if data == "adm_home":
        await msg.edit_text(admin_home_text(), reply_markup=admin_home_kb())

    # ══ إحصائيات ══════════════════════════════════════════════
    elif data == "adm_stats":
        stats   = get_stats()
        by_plan = stats["by_plan"]
        text = (
            f"📊 **الإحصائيات التفصيلية**\n━━━━━━━━━━━━━━━━━━━━\n\n"
            f"👥 إجمالي المستخدمين: **{stats['total']}**\n"
            f"📡 نشطون اليوم: **{stats['active_today']}**\n"
            f"🚫 محظورون: **{stats['banned']}**\n\n"
            f"📦 **توزيع الباقات:**\n"
        )
        for k, p in PLANS.items():
            count = by_plan.get(k, 0)
            pct   = round(count / max(stats['total'], 1) * 100)
            bar   = "█" * (pct // 10) + "░" * (10 - pct // 10)
            text += f"  {p['name']}: **{count}** [{bar}] {pct}%\n"
        await msg.edit_text(text, reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("📈 أكثر نشاطاً",  callback_data="adm_top_users"),
                InlineKeyboardButton("🆕 أحدث مستخدم",  callback_data="adm_newest"),
            ],
            [InlineKeyboardButton("🔙 رجوع", callback_data="adm_home")],
        ]))

    elif data == "adm_top_users":
        users = get_all_users()
        top   = sorted(users, key=lambda u: u[4] or 0, reverse=True)[:10]
        text  = "🏆 **أكثر المستخدمين نشاطاً اليوم:**\n━━━━━━━━━━━━━━━\n"
        for i, u in enumerate(top, 1):
            text += f"{i}. @{u[1] or u[0]} — **{u[4]}** طلب — {u[2]}\n"
        await msg.edit_text(text, reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 رجوع", callback_data="adm_stats")]
        ]))

    elif data == "adm_newest":
        users  = get_all_users()
        newest = users[:5]
        text   = "🆕 **أحدث المستخدمين:**\n━━━━━━━━━━━━━━━\n"
        for u in newest:
            text += f"• @{u[1] or u[0]} — {u[6][:10] if len(u)>6 and u[6] else 'غير معروف'}\n"
        await msg.edit_text(text, reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 رجوع", callback_data="adm_stats")]
        ]))

    # ══ المستخدمون ════════════════════════════════════════════
    elif data.startswith("adm_users_"):
        page  = int(data.split("_")[-1])
        users = get_all_users()
        per   = 8
        total_pages = max(1, (len(users) + per - 1) // per)
        chunk = users[page * per: page * per + per]
        text  = f"👥 **المستخدمون** ({len(users)} إجمالاً) — صفحة {page+1}/{total_pages}\n━━━━━━━━━━━━━━━\n"
        rows  = []
        for u in chunk:
            uid2, uname, plan, expiry, count, banned = u[0], u[1], u[2], u[3], u[4], u[5]
            icon  = "🚫" if banned else "✅"
            label = f"{icon} @{uname or uid2} | {plan} | {count}طلب"
            text += f"{label}\n"
            rows.append([InlineKeyboardButton(label, callback_data=f"adm_user_{uid2}")])
        nav = []
        if page > 0:
            nav.append(InlineKeyboardButton("◀️", callback_data=f"adm_users_{page-1}"))
        nav.append(InlineKeyboardButton(f"{page+1}/{total_pages}", callback_data="adm_stats"))
        if page < total_pages - 1:
            nav.append(InlineKeyboardButton("▶️", callback_data=f"adm_users_{page+1}"))
        rows.append(nav)
        rows.append([
            InlineKeyboardButton("🔍 بحث بـ ID",     callback_data="adm_search_user"),
            InlineKeyboardButton("🔙 رجوع",           callback_data="adm_home"),
        ])
        await msg.edit_text(text, reply_markup=InlineKeyboardMarkup(rows))

    elif data == "adm_search_user":
        set_state(uid, "search_user")
        await msg.edit_text(
            "🔍 **بحث عن مستخدم**\n\nأرسل الـ ID أو الـ username:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_users_0")]])
        )

    elif data.startswith("adm_user_"):
        target_id = int(data.split("_")[-1])
        await show_user_panel(msg, target_id)

    elif data.startswith("adm_sp_"):
        parts    = data.split("_")
        target   = int(parts[2])
        plan_key = parts[3]
        days     = int(parts[4])
        set_plan(target, plan_key, days)
        pname = PLANS.get(plan_key, {}).get("name", plan_key)
        await update.answer(f"✅ تم تفعيل {pname} لـ {days} يوم", show_alert=True)
        await show_user_panel(msg, target)

    elif data.startswith("adm_reset_"):
        target = int(data.split("_")[-1])
        reset_user_usage(target)
        await update.answer("✅ تم تصفير الاستخدام", show_alert=True)
        await show_user_panel(msg, target)

    elif data.startswith("adm_ban_"):
        target = int(data.split("_")[-1])
        set_state(uid, "ban_reason", {"target": target})
        await msg.edit_text(
            f"🚫 **حظر المستخدم `{target}`**\n\nأرسل سبب الحظر (أو أرسل - لتخطي):",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data=f"adm_user_{target}")]])
        )

    elif data.startswith("adm_unban_"):
        target = int(data.split("_")[-1])
        unban_user(target)
        await update.answer("✅ تم رفع الحظر", show_alert=True)
        await show_user_panel(msg, target)

    elif data.startswith("adm_msg_"):
        target = int(data.split("_")[-1])
        set_state(uid, "send_msg_user", {"target": target})
        await msg.edit_text(
            f"💬 **إرسال رسالة للمستخدم `{target}`**\n\nاكتب الرسالة:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data=f"adm_user_{target}")]])
        )

    # ══ المحظورون ═════════════════════════════════════════════
    elif data == "adm_banned":
        users  = get_all_users()
        banned = [u for u in users if u[5] == 1]
        text   = f"🚫 **المحظورون ({len(banned)})**\n━━━━━━━━━━━━━━━\n"
        rows   = []
        if not banned:
            text += "لا يوجد مستخدمون محظورون ✅"
        for u in banned:
            text += f"• @{u[1] or u[0]}\n"
            rows.append([InlineKeyboardButton(
                f"✅ رفع حظر @{u[1] or u[0]}",
                callback_data=f"adm_unban_{u[0]}"
            )])
        rows.append([InlineKeyboardButton("🔙 رجوع", callback_data="adm_home")])
        await msg.edit_text(text, reply_markup=InlineKeyboardMarkup(rows))

    # ══ الباقات ═══════════════════════════════════════════════
    elif data == "adm_plans":
        text = "📦 **إدارة الباقات:**\n━━━━━━━━━━━━━━━\n"
        rows = []
        for key, plan in PLANS.items():
            price  = "مجاني" if plan["price"] == 0 else f"${plan['price']}/{plan['period']}"
            limit  = "∞" if plan["limit"] == -1 else f"{plan['limit']}/يوم"
            ai_mod = config.PLAN_AI_MODELS.get(key, "groq")
            text  += f"\n**{plan['name']}** — {price} — {limit} طلب — 🤖 {ai_mod}\n"
            rows.append([
                InlineKeyboardButton(f"👁️ {plan['name']}", callback_data=f"adm_viewplan_{key}"),
                InlineKeyboardButton(f"🤖 تغيير AI", callback_data=f"adm_plan_ai_{key}"),
            ])
        rows.append([InlineKeyboardButton("🔙 رجوع", callback_data="adm_home")])
        await msg.edit_text(text, reply_markup=InlineKeyboardMarkup(rows))

    elif data.startswith("adm_viewplan_"):
        key  = data.split("_")[-1]
        plan = PLANS.get(key, {})
        ai_m = config.PLAN_AI_MODELS.get(key, "groq")
        text = (
            f"📦 **{plan.get('name',key)}**\n━━━━━━━━━━━━━━━\n"
            f"💰 السعر: {'مجاني' if plan.get('price',0)==0 else f\"${plan['price']}/{plan['period']}\"}\n"
            f"📊 الحد اليومي: {'غير محدود' if plan.get('limit',-1)==-1 else plan['limit']}\n"
            f"🤖 موديل AI: **{ai_m}** ({config.AI_MODEL_NAMES.get(ai_m,'?')})\n\n"
            f"✨ المميزات:\n"
        )
        for f in plan.get("features", []):
            text += f"  {f}\n"
        text += f"\n📤 صيغ التصدير: {', '.join(plan.get('export_formats', []))}"
        await msg.edit_text(text, reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🤖 تغيير موديل AI", callback_data=f"adm_plan_ai_{key}")],
            [InlineKeyboardButton("🔙 رجوع", callback_data="adm_plans")],
        ]))

    # ══ تغيير موديل AI لباقة ══════════════════════════════════
    elif data.startswith("adm_plan_ai_"):
        plan_key  = data.replace("adm_plan_ai_", "")
        plan_name = PLANS.get(plan_key, {}).get("name", plan_key)
        current   = config.PLAN_AI_MODELS.get(plan_key, "groq")
        await msg.edit_text(
            f"🤖 **تغيير موديل AI لباقة {plan_name}**\n\n"
            f"الموديل الحالي: **{current}** ({config.AI_MODEL_NAMES.get(current,'?')})\n\n"
            f"اختر الموديل الجديد:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🆓 Groq (مجاني)",   callback_data=f"adm_set_ai_{plan_key}_groq")],
                [InlineKeyboardButton("💎 Gemini",          callback_data=f"adm_set_ai_{plan_key}_gemini")],
                [InlineKeyboardButton("🚀 OpenAI GPT",      callback_data=f"adm_set_ai_{plan_key}_openai")],
                [InlineKeyboardButton("🔙 رجوع",            callback_data="adm_plans")],
            ])
        )

    elif data.startswith("adm_set_ai_"):
        parts    = data.replace("adm_set_ai_", "").rsplit("_", 1)
        plan_key = parts[0]
        provider = parts[1]
        config.PLAN_AI_MODELS[plan_key] = provider
        plan_name = PLANS.get(plan_key, {}).get("name", plan_key)
        await update.answer(f"✅ {plan_name} → {provider}", show_alert=True)
        await msg.edit_text(admin_home_text(), reply_markup=admin_home_kb())

    # ══ المميزات ══════════════════════════════════════════════
    elif data == "adm_features":
        feature_names = {
            "rawData":"📄 Raw Data","htmlData":"📝 HTML","allLinks":"🔗 روابط",
            "allParagraphs":"📃 فقرات","allImages":"🌄 صور","allAudio":"🎵 صوت",
            "allVideo":"🎥 فيديو","allPdf":"📚 PDF","cookies":"🍪 Cookies",
            "localStorage":"📦 LocalStorage","metadata":"📊 Metadata",
            "screenshot":"📷 Screenshot","screenRecord":"🎬 تسجيل","crawlWeb":"🕷️ زحف",
            "exportCSV":"📊 تصدير CSV","exportJSON":"🗂️ تصدير JSON",
            "exportXLSX":"📗 تصدير Excel","exportXML":"📋 تصدير XML",
            "exportMarkdown":"📝 تصدير Markdown",
        }
        text = "⚙️ **المميزات — اضغط لتفعيل/تعطيل:**\n━━━━━━━━━━━━━━━\n"
        rows = []
        items = list(feature_names.items())
        for i in range(0, len(items), 2):
            row = []
            for key, name in items[i:i+2]:
                status = "✅" if config.FEATURES.get(key) else "❌"
                row.append(InlineKeyboardButton(f"{status} {name}", callback_data=f"adm_toggle_{key}"))
            rows.append(row)
        rows.append([InlineKeyboardButton("🔙 رجوع", callback_data="adm_home")])
        await msg.edit_text(text + "\n".join(
            f"{'✅' if config.FEATURES.get(k) else '❌'} {n}"
            for k, n in feature_names.items()
        ), reply_markup=InlineKeyboardMarkup(rows))

    elif data.startswith("adm_toggle_"):
        key = data.replace("adm_toggle_", "")
        if key in config.FEATURES:
            config.FEATURES[key] = not config.FEATURES[key]
            status = "✅ مفعّل" if config.FEATURES[key] else "❌ معطّل"
            await update.answer(f"{key}: {status}", show_alert=True)
        feature_names = {
            "rawData":"📄 Raw Data","htmlData":"📝 HTML","allLinks":"🔗 روابط",
            "allParagraphs":"📃 فقرات","allImages":"🌄 صور","allAudio":"🎵 صوت",
            "allVideo":"🎥 فيديو","allPdf":"📚 PDF","cookies":"🍪 Cookies",
            "localStorage":"📦 LocalStorage","metadata":"📊 Metadata",
            "screenshot":"📷 Screenshot","screenRecord":"🎬 تسجيل","crawlWeb":"🕷️ زحف",
            "exportCSV":"📊 تصدير CSV","exportJSON":"🗂️ تصدير JSON",
            "exportXLSX":"📗 تصدير Excel","exportXML":"📋 تصدير XML",
            "exportMarkdown":"📝 تصدير Markdown",
        }
        rows = []
        items = list(feature_names.items())
        for i in range(0, len(items), 2):
            row = []
            for k, n in items[i:i+2]:
                s = "✅" if config.FEATURES.get(k) else "❌"
                row.append(InlineKeyboardButton(f"{s} {n}", callback_data=f"adm_toggle_{k}"))
            rows.append(row)
        rows.append([InlineKeyboardButton("🔙 رجوع", callback_data="adm_home")])
        await msg.edit_text(
            "⚙️ **المميزات:**\n" + "\n".join(
                f"{'✅' if config.FEATURES.get(k) else '❌'} {n}"
                for k, n in feature_names.items()
            ),
            reply_markup=InlineKeyboardMarkup(rows)
        )

    # ══ النصوص ════════════════════════════════════════════════
    elif data == "adm_texts":
        await msg.edit_text(
            f"📝 **تعديل النصوص:**\n━━━━━━━━━━━━━━━\n\n"
            f"اختر النص الذي تريد تعديله:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("👋 رسالة الترحيب /start", callback_data="adm_edit_start")],
                [InlineKeyboardButton("📞 نص التواصل",            callback_data="adm_edit_contact")],
                [InlineKeyboardButton("🤖 اسم البوت",             callback_data="adm_edit_botname")],
                [InlineKeyboardButton("🆘 نص المساعدة /help",     callback_data="adm_edit_help")],
                [InlineKeyboardButton("🔧 رسالة الصيانة",         callback_data="adm_edit_maintenance")],
                [InlineKeyboardButton("🔙 رجوع",                  callback_data="adm_home")],
            ])
        )

    elif data == "adm_edit_start":
        set_state(uid, "edit_start")
        await msg.edit_text(
            f"📝 **نص الترحيب الحالي:**\n\n`{config.START_TEXT[:300]}...`\n\n✍️ أرسل النص الجديد:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_texts")]])
        )

    elif data == "adm_edit_contact":
        set_state(uid, "edit_contact")
        await msg.edit_text(
            f"📞 **نص التواصل الحالي:**\n\n`{config.CONTACT_TEXT[:300]}`\n\n✍️ أرسل النص الجديد:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_texts")]])
        )

    elif data == "adm_edit_botname":
        set_state(uid, "edit_botname")
        await msg.edit_text(
            f"🤖 **اسم البوت الحالي:** `{config.BOT_NAME}`\n\n✍️ أرسل الاسم الجديد:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_texts")]])
        )

    elif data == "adm_edit_help":
        set_state(uid, "edit_help")
        await msg.edit_text(
            "🆘 **أرسل نص المساعدة الجديد:**",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_texts")]])
        )

    elif data == "adm_edit_maintenance":
        set_state(uid, "edit_maintenance_msg")
        await msg.edit_text(
            f"🔧 **رسالة الصيانة الحالية:**\n\n`{config.MAINTENANCE_MSG}`\n\n✍️ أرسل الرسالة الجديدة:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_texts")]])
        )

    # ══ برودكاست ══════════════════════════════════════════════
    elif data == "adm_broadcast":
        await msg.edit_text(
            "📢 **برودكاست — اختر الفئة المستهدفة:**",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📣 كل المستخدمين",      callback_data="adm_bc_all")],
                [InlineKeyboardButton("🚀 مستخدمو Pro فقط",   callback_data="adm_bc_pro")],
                [InlineKeyboardButton("⭐ مستخدمو Basic فقط", callback_data="adm_bc_basic")],
                [InlineKeyboardButton("🆓 المجانيون فقط",     callback_data="adm_bc_free")],
                [InlineKeyboardButton("🔙 رجوع",              callback_data="adm_home")],
            ])
        )

    elif data.startswith("adm_bc_"):
        target_group = data.split("_")[-1]
        set_state(uid, "broadcast", {"group": target_group})
        labels = {"all": "كل المستخدمين", "pro": "Pro فقط", "basic": "Basic فقط", "free": "المجانيون"}
        await msg.edit_text(
            f"📢 **برودكاست لـ: {labels.get(target_group, target_group)}**\n\n✍️ أرسل الرسالة الآن:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_broadcast")]])
        )

    # ══ الأدمن ════════════════════════════════════════════════
    elif data == "adm_admins":
        text = f"🔧 **قائمة الأدمن ({len(config.ADMINS)}):**\n━━━━━━━━━━━━━━━\n"
        rows = []
        for admin_id in config.ADMINS:
            u    = get_user(admin_id)
            name = f"@{u['username']}" if u and u.get("username") else str(admin_id)
            text += f"• {name} (`{admin_id}`)\n"
            if admin_id != uid:
                rows.append([InlineKeyboardButton(f"🗑️ إزالة {name}", callback_data=f"adm_rmadmin_{admin_id}")])
        rows.append([InlineKeyboardButton("➕ إضافة أدمن", callback_data="adm_addadmin")])
        rows.append([InlineKeyboardButton("🔙 رجوع",       callback_data="adm_home")])
        await msg.edit_text(text, reply_markup=InlineKeyboardMarkup(rows))

    elif data == "adm_addadmin":
        set_state(uid, "add_admin")
        await msg.edit_text(
            "➕ **إضافة أدمن جديد**\n\nأرسل الـ user_id الخاص به:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_admins")]])
        )

    elif data.startswith("adm_rmadmin_"):
        target = int(data.split("_")[-1])
        if target in config.ADMINS and target != uid:
            config.ADMINS.remove(target)
            await update.answer("✅ تم الإزالة", show_alert=True)
        await msg.edit_text(admin_home_text(), reply_markup=admin_home_kb())

    # ══ الدعم ═════════════════════════════════════════════════
    elif data == "adm_support":
        await msg.edit_text(
            "💬 **رسائل الدعم**\n━━━━━━━━━━━━━━━\n\n"
            "لإرسال رسالة لمستخدم معين:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📨 رسالة لمستخدم بـ ID", callback_data="adm_msg_by_id")],
                [InlineKeyboardButton("🔙 رجوع",                 callback_data="adm_home")],
            ])
        )

    elif data == "adm_msg_by_id":
        set_state(uid, "msg_by_id")
        await msg.edit_text(
            "📨 أرسل الـ user_id للمستخدم:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_support")]])
        )

    # ══ تنظيف ═════════════════════════════════════════════════
    elif data == "adm_cleanup":
        await msg.edit_text(
            "🗑️ **تنظيف البيانات:**\n━━━━━━━━━━━━━━━",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 تصفير كل الإحصائيات اليومية", callback_data="adm_resetall")],
                [InlineKeyboardButton("🗑️ حذف المستخدمين المحظورين",    callback_data="adm_delbanned")],
                [InlineKeyboardButton("🔙 رجوع",                          callback_data="adm_home")],
            ])
        )

    elif data == "adm_resetall":
        import sqlite3
        conn = sqlite3.connect("subscriptions.db")
        conn.execute("UPDATE subscriptions SET daily_count=0")
        conn.commit()
        conn.close()
        await update.answer("✅ تم تصفير كل الإحصائيات اليومية", show_alert=True)
        await msg.edit_text(admin_home_text(), reply_markup=admin_home_kb())

    elif data == "adm_delbanned":
        import sqlite3
        conn = sqlite3.connect("subscriptions.db")
        n = conn.execute("DELETE FROM subscriptions WHERE is_banned=1").rowcount
        conn.commit()
        conn.close()
        await update.answer(f"✅ تم حذف {n} مستخدم محظور", show_alert=True)
        await msg.edit_text(admin_home_text(), reply_markup=admin_home_kb())

    # ══ لوجز ══════════════════════════════════════════════════
    elif data == "adm_logs":
        import os
        log_text = "📋 **آخر الأحداث:**\n━━━━━━━━━━━━━━━\n"
        if os.path.exists("bot.log"):
            with open("bot.log", "r", encoding="utf-8", errors="ignore") as f:
                lines = f.readlines()[-20:]
            log_text += "".join(lines)[-3000:]
        else:
            log_text += "لا يوجد سجل بعد"
        await msg.edit_text(log_text[:4000], reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 رجوع", callback_data="adm_home")]
        ]))

    # ══ إعادة تشغيل ═══════════════════════════════════════════
    elif data == "adm_restart":
        await msg.edit_text(
            "🔄 **إعادة تشغيل البوت؟**",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("✅ نعم، أعد التشغيل", callback_data="adm_confirm_restart"),
                    InlineKeyboardButton("❌ إلغاء",             callback_data="adm_home"),
                ]
            ])
        )

    elif data == "adm_confirm_restart":
        await msg.edit_text("🔄 جاري إعادة التشغيل...")
        import os, sys
        os.execv(sys.executable, [sys.executable] + sys.argv)

    # ══════════════════════════════════════════════════════════
    #  الميزات الجديدة الخمس
    # ══════════════════════════════════════════════════════════

    # ── 1. إعدادات AI ─────────────────────────────────────────
    elif data == "adm_ai_settings":
        from admin import handle_extra_admin_callback
        return await handle_extra_admin_callback(bot, update, "adm_ai_status")

    # ── 2. وضع الصيانة ────────────────────────────────────────
    elif data == "adm_maintenance":
        status = "🔴 مفعّل" if config.MAINTENANCE_MODE else "🟢 معطّل"
        await msg.edit_text(
            f"🔧 **إدارة وضع الصيانة**\n━━━━━━━━━━━━━━━\n\n"
            f"الحالة الحالية: **{status}**\n\n"
            f"رسالة الصيانة:\n`{config.MAINTENANCE_MSG}`",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(
                    "🔴 تفعيل الصيانة" if not config.MAINTENANCE_MODE else "🟢 إيقاف الصيانة",
                    callback_data="adm_toggle_maintenance"
                )],
                [InlineKeyboardButton("✏️ تعديل رسالة الصيانة", callback_data="adm_edit_maintenance")],
                [InlineKeyboardButton("🔙 رجوع", callback_data="adm_home")],
            ])
        )

    elif data == "adm_toggle_maintenance":
        config.MAINTENANCE_MODE = not config.MAINTENANCE_MODE
        status = "🔴 مفعّل" if config.MAINTENANCE_MODE else "🟢 معطّل"
        await update.answer(f"وضع الصيانة: {status}", show_alert=True)
        await msg.edit_text(admin_home_text(), reply_markup=admin_home_kb())

    # ── 3. إحصائيات التصدير ───────────────────────────────────
    elif data == "adm_export_stats":
        import sqlite3
        try:
            conn = sqlite3.connect("subscriptions.db")
            # محاولة قراءة جدول export_logs لو موجود
            try:
                rows = conn.execute(
                    "SELECT format, COUNT(*) as cnt FROM export_logs GROUP BY format ORDER BY cnt DESC"
                ).fetchall()
                total_exports = conn.execute("SELECT COUNT(*) FROM export_logs").fetchone()[0]
                today  = __import__("datetime").datetime.now().strftime("%Y-%m-%d")
                today_exports = conn.execute(
                    "SELECT COUNT(*) FROM export_logs WHERE date=?", (today,)
                ).fetchone()[0]
                text = (
                    f"📈 **إحصائيات التصدير**\n━━━━━━━━━━━━━━━\n\n"
                    f"📦 إجمالي عمليات التصدير: **{total_exports}**\n"
                    f"📅 اليوم: **{today_exports}**\n\n"
                    f"**توزيع الصيغ:**\n"
                )
                for fmt, cnt in rows:
                    text += f"  {fmt.upper()}: **{cnt}**\n"
            except:
                text = "📈 **إحصائيات التصدير**\n\nلم يتم تصدير أي بيانات بعد."
            conn.close()
        except Exception as e:
            text = f"❌ خطأ: {e}"
        await msg.edit_text(text, reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 رجوع", callback_data="adm_home")]
        ]))

    # ── 4. حدود الطلبات ───────────────────────────────────────
    elif data == "adm_rate_limits":
        await msg.edit_text(
            f"⚡ **إعدادات حدود الطلبات**\n━━━━━━━━━━━━━━━\n\n"
            f"⏱️ التأخير بين الطلبات: **{config.RATE_LIMIT_SECONDS} ثانية**\n"
            f"📁 أقصى حجم ملف: **{config.MAX_FILE_SIZE_MB} MB**\n"
            f"📝 تسجيل الطلبات: **{'✅ مفعّل' if config.LOG_REQUESTS else '❌ معطّل'}**\n\n"
            f"**حدود الباقات اليومية:**\n" +
            "\n".join(
                f"  {p['name']}: {'∞' if p['limit']==-1 else p['limit']} طلب/يوم"
                for p in config.PLANS.values()
            ),
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("⏱️ تغيير التأخير",   callback_data="adm_set_ratelimit"),
                    InlineKeyboardButton("📁 تغيير الحجم الأقصى", callback_data="adm_set_maxsize"),
                ],
                [InlineKeyboardButton(
                    "📝 إيقاف تسجيل الطلبات" if config.LOG_REQUESTS else "📝 تفعيل تسجيل الطلبات",
                    callback_data="adm_toggle_logging"
                )],
                [InlineKeyboardButton("🔙 رجوع", callback_data="adm_home")],
            ])
        )

    elif data == "adm_toggle_logging":
        config.LOG_REQUESTS = not config.LOG_REQUESTS
        status = "✅ مفعّل" if config.LOG_REQUESTS else "❌ معطّل"
        await update.answer(f"تسجيل الطلبات: {status}", show_alert=True)
        await msg.edit_text(admin_home_text(), reply_markup=admin_home_kb())

    elif data == "adm_set_ratelimit":
        set_state(uid, "set_ratelimit")
        await msg.edit_text(
            f"⏱️ **تغيير التأخير بين الطلبات**\n\n"
            f"القيمة الحالية: **{config.RATE_LIMIT_SECONDS} ثانية**\n\n"
            f"أرسل القيمة الجديدة (بالثواني، مثال: 3):",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_rate_limits")]])
        )

    elif data == "adm_set_maxsize":
        set_state(uid, "set_maxsize")
        await msg.edit_text(
            f"📁 **تغيير أقصى حجم ملف**\n\n"
            f"القيمة الحالية: **{config.MAX_FILE_SIZE_MB} MB**\n\n"
            f"أرسل القيمة الجديدة (بالميجابايت، مثال: 50):",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_rate_limits")]])
        )

    # ── 5. أكواد الترقية ──────────────────────────────────────
    elif data == "adm_promo_codes":
        import sqlite3
        conn = sqlite3.connect("subscriptions.db")
        try:
            conn.execute("""CREATE TABLE IF NOT EXISTS promo_codes (
                code TEXT PRIMARY KEY,
                plan TEXT, days INTEGER,
                max_uses INTEGER DEFAULT 1,
                used_count INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")
            conn.commit()
            codes = conn.execute(
                "SELECT code, plan, days, max_uses, used_count FROM promo_codes ORDER BY created_at DESC LIMIT 10"
            ).fetchall()
        except:
            codes = []
        conn.close()

        text = "🎁 **أكواد الترقية**\n━━━━━━━━━━━━━━━\n\n"
        if not codes:
            text += "لا توجد أكواد بعد.\n"
        else:
            for code, plan, days, max_uses, used in codes:
                pname = config.PLANS.get(plan, {}).get("name", plan)
                text += f"• `{code}` → {pname} ({days}يوم) — {used}/{max_uses} استخدام\n"

        await msg.edit_text(text, reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ إنشاء كود جديد", callback_data="adm_create_promo")],
            [InlineKeyboardButton("🗑️ حذف كل الأكواد", callback_data="adm_clear_promos")],
            [InlineKeyboardButton("🔙 رجوع",            callback_data="adm_home")],
        ]))

    elif data == "adm_create_promo":
        await msg.edit_text(
            "🎁 **إنشاء كود ترقية جديد**\n\nاختر الباقة:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(p["name"], callback_data=f"adm_promo_plan_{k}")]
                for k, p in config.PLANS.items() if k != "free"
            ] + [[InlineKeyboardButton("🔙 رجوع", callback_data="adm_promo_codes")]])
        )

    elif data.startswith("adm_promo_plan_"):
        plan_key = data.replace("adm_promo_plan_", "")
        set_state(uid, "create_promo", {"plan": plan_key})
        await msg.edit_text(
            f"🎁 **كود ترقية — باقة {config.PLANS[plan_key]['name']}**\n\n"
            f"أرسل: `كود_الترقية|عدد_الأيام|أقصى_استخدامات`\n\n"
            f"مثال: `SUMMER2025|30|5`",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_promo_codes")]])
        )

    elif data == "adm_clear_promos":
        import sqlite3
        conn = sqlite3.connect("subscriptions.db")
        try:
            n = conn.execute("DELETE FROM promo_codes").rowcount
            conn.commit()
        except:
            n = 0
        conn.close()
        await update.answer(f"✅ تم حذف {n} كود", show_alert=True)
        await msg.edit_text(admin_home_text(), reply_markup=admin_home_kb())

    # ── 6. إعلان مخصص ─────────────────────────────────────────
    elif data == "adm_custom_banner":
        current = getattr(config, "CUSTOM_BANNER", "")
        await msg.edit_text(
            f"📣 **إعلان مخصص (يظهر في /start)**\n━━━━━━━━━━━━━━━\n\n"
            f"الحالة: **{'✅ مفعّل' if current else '❌ لا يوجد'}**\n\n"
            + (f"النص الحالي:\n`{current[:200]}`" if current else "لا يوجد إعلان حالياً."),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✏️ تعيين إعلان جديد",   callback_data="adm_set_banner")],
                [InlineKeyboardButton("🗑️ حذف الإعلان الحالي", callback_data="adm_del_banner")],
                [InlineKeyboardButton("🔙 رجوع",               callback_data="adm_home")],
            ])
        )

    elif data == "adm_set_banner":
        set_state(uid, "set_banner")
        await msg.edit_text(
            "📣 **أرسل نص الإعلان الجديد:**\n\n(يظهر أسفل رسالة /start لكل المستخدمين)",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_custom_banner")]])
        )

    elif data == "adm_del_banner":
        config.CUSTOM_BANNER = ""
        await update.answer("✅ تم حذف الإعلان", show_alert=True)
        await msg.edit_text(admin_home_text(), reply_markup=admin_home_kb())

    # ══ proxy + export + ai ═══════════════════════════════════
    elif data in ("adm_proxy_status", "adm_proxy_test", "adm_export_users"):
        return await handle_extra_admin_callback(bot, update, data)


# ══════════════════════════════════════════════════════════════
#  Helper: عرض بانل مستخدم
# ══════════════════════════════════════════════════════════════

async def show_user_panel(msg, target_id: int):
    user = get_user(target_id)
    if not user:
        return await msg.edit_text(
            f"❌ المستخدم `{target_id}` غير موجود في قاعدة البيانات",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع", callback_data="adm_users_0")]])
        )
    plan   = PLANS.get(user["plan"], PLANS["free"])
    expiry = user["expiry"] or "مستمر"
    status = "🚫 محظور" if user.get("is_banned") else "✅ نشط"
    ai_mod = config.PLAN_AI_MODELS.get(user["plan"], "groq")
    text = (
        f"👤 **تفاصيل المستخدم**\n━━━━━━━━━━━━━━━\n"
        f"🆔 ID: `{target_id}`\n"
        f"👤 اليوزر: @{user['username'] or 'بدون'}\n"
        f"📦 الباقة: **{plan['name']}**\n"
        f"🤖 موديل AI: **{ai_mod}**\n"
        f"📅 تنتهي: `{expiry}`\n"
        f"📊 طلبات اليوم: **{user['daily_count']}**\n"
        f"الحالة: {status}\n"
        f"📆 التسجيل: {str(user.get('created_at',''))[:10]}"
    )
    ban_row = (
        [InlineKeyboardButton("✅ رفع الحظر", callback_data=f"adm_unban_{target_id}")]
        if user.get("is_banned") else
        [InlineKeyboardButton("🚫 حظر",       callback_data=f"adm_ban_{target_id}")]
    )
    await msg.edit_text(text, reply_markup=InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🆓 مجاني",   callback_data=f"adm_sp_{target_id}_free_0"),
            InlineKeyboardButton("⭐ أساسي",   callback_data=f"adm_sp_{target_id}_basic_30"),
            InlineKeyboardButton("🚀 Pro",     callback_data=f"adm_sp_{target_id}_pro_30"),
        ],
        [
            InlineKeyboardButton("📅 30 يوم",  callback_data=f"adm_sp_{target_id}_pro_30"),
            InlineKeyboardButton("📅 90 يوم",  callback_data=f"adm_sp_{target_id}_pro_90"),
            InlineKeyboardButton("📅 365 يوم", callback_data=f"adm_sp_{target_id}_pro_365"),
        ],
        [InlineKeyboardButton("🔄 تصفير الاستخدام", callback_data=f"adm_reset_{target_id}")],
        ban_row,
        [InlineKeyboardButton("💬 إرسال رسالة",     callback_data=f"adm_msg_{target_id}")],
        [InlineKeyboardButton("🔙 رجوع للقائمة",    callback_data="adm_users_0")],
    ]))


# ══════════════════════════════════════════════════════════════
#  handlers إضافية - AI + Proxy + تصدير
# ══════════════════════════════════════════════════════════════

async def handle_extra_admin_callback(bot, update, data: str):
    uid = update.from_user.id
    msg = update.message

    if data == "adm_ai_status":
        from ai_assistant import get_ai_status
        providers = ["groq", "gemini", "openai"]
        rows = []
        for p in providers:
            rows.append([InlineKeyboardButton(
                f"✏️ تغيير موديل {p.upper()}",
                callback_data=f"adm_change_ai_model_{p}"
            )])

        # أزرار تغيير AI لكل باقة
        for plan_key in config.PLANS:
            plan_name = config.PLANS[plan_key]["name"]
            rows.append([InlineKeyboardButton(
                f"🔄 {plan_name} → AI",
                callback_data=f"adm_plan_ai_{plan_key}"
            )])
        rows.append([InlineKeyboardButton("🔙 رجوع", callback_data="adm_home")])
        await msg.edit_text(get_ai_status(), reply_markup=InlineKeyboardMarkup(rows))

    elif data.startswith("adm_change_ai_model_"):
        provider = data.replace("adm_change_ai_model_", "")
        set_state(uid, "change_ai_model", {"provider": provider})
        models_map = {
            "groq":   ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768", "gemma2-9b-it"],
            "gemini": ["gemini-2.0-flash", "gemini-1.5-flash-latest", "gemini-1.5-flash-8b"],
            "openai": ["gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo"],
        }
        models = models_map.get(provider, [])
        rows   = [[InlineKeyboardButton(m, callback_data=f"adm_set_aimodel_{provider}_{m}")] for m in models]
        rows.append([InlineKeyboardButton("🔙 رجوع", callback_data="adm_ai_status")])
        await msg.edit_text(
            f"🤖 **اختر موديل {provider.upper()}:**\n\nالحالي: `{config.AI_MODEL_NAMES.get(provider,'?')}`",
            reply_markup=InlineKeyboardMarkup(rows)
        )

    elif data.startswith("adm_set_aimodel_"):
        parts    = data.replace("adm_set_aimodel_", "").split("_", 1)
        provider = parts[0]
        model    = parts[1]
        config.AI_MODEL_NAMES[provider] = model
        await update.answer(f"✅ {provider} → {model}", show_alert=True)
        from ai_assistant import get_ai_status
        await msg.edit_text(get_ai_status(), reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 رجوع", callback_data="adm_home")]
        ]))

    elif data == "adm_proxy_status":
        from proxy_manager import get_proxy_status
        await msg.edit_text(
            get_proxy_status(),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 اختبار البروكسيات", callback_data="adm_proxy_test")],
                [InlineKeyboardButton("🔙 رجوع",               callback_data="adm_home")],
            ])
        )

    elif data == "adm_proxy_test":
        from proxy_manager import PROXY_LIST, requests_get
        if not PROXY_LIST:
            return await update.answer("لا توجد بروكسيات مضبوطة", show_alert=True)
        await msg.edit_text("🔄 جاري اختبار البروكسيات...")
        results = []
        for proxy_url in PROXY_LIST:
            try:
                import time
                t = time.time()
                requests_get("https://httpbin.org/ip", timeout=8)
                ms = int((time.time()-t)*1000)
                results.append(f"✅ `{proxy_url[:35]}` — {ms}ms")
            except:
                results.append(f"❌ `{proxy_url[:35]}`")
        await msg.edit_text(
            "📊 **نتائج اختبار البروكسيات:**\n\n" + "\n".join(results),
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع", callback_data="adm_proxy_status")]])
        )

    elif data == "adm_export_users":
        import sqlite3, io
        conn = sqlite3.connect("subscriptions.db")
        rows = conn.execute("SELECT * FROM subscriptions").fetchall()
        conn.close()
        output = "user_id,username,plan,expiry,daily_count,is_banned,created_at\n"
        for r in rows:
            output += ",".join(str(x or "") for x in r) + "\n"
        fname = "users_export.csv"
        with open(fname, "w", encoding="utf-8") as f:
            f.write(output)
        await bot.send_document(uid, fname, caption=f"📊 تصدير {len(rows)} مستخدم")
        import os; os.remove(fname)
        await update.answer("✅ تم التصدير", show_alert=True)
