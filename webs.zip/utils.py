# ============================================================
#  Utils - الأزرار والنصوص
# ============================================================

from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import (
    START_TEXT, CONTACT_TEXT, FINISHED_PROGRESS_STR,
    UN_FINISHED_PROGRESS_STR, REPO, PLANS, FEATURES
)

# ==================== أزرار الستارت ====================
START_BUTTON = InlineKeyboardMarkup([
    [
        InlineKeyboardButton("📦 الباقات", callback_data="cbplans"),
        InlineKeyboardButton("📞 تواصل", callback_data="cbcontact"),
    ],
    [
        InlineKeyboardButton("📊 حسابي", callback_data="cbmyplan"),
    ]
])

# ==================== أزرار الخيارات الرئيسية ====================
def get_options_keyboard(user_features: list) -> InlineKeyboardMarkup:
    """يبني الكيبورد بناءً على مميزات المستخدم"""
    buttons = []

    row1 = []
    if "rawData" in user_features and FEATURES.get("rawData"):
        row1.append(InlineKeyboardButton("📄 Full Content", callback_data="cbrdata"))
    if "htmlData" in user_features and FEATURES.get("htmlData"):
        row1.append(InlineKeyboardButton("📝 HTML Data", callback_data="cbhtmldata"))
    if row1: buttons.append(row1)

    row2 = []
    if "allLinks" in user_features and FEATURES.get("allLinks"):
        row2.append(InlineKeyboardButton("🔗 All Links", callback_data="cballlinks"))
    if "allParagraphs" in user_features and FEATURES.get("allParagraphs"):
        row2.append(InlineKeyboardButton("📃 Paragraphs", callback_data="cballparagraphs"))
    if row2: buttons.append(row2)

    row3 = []
    if "allImages" in user_features and FEATURES.get("allImages"):
        row3.append(InlineKeyboardButton("🌄 All Images", callback_data="cballimages"))
    if row3: buttons.append(row3)

    row4 = []
    if "allAudio" in user_features and FEATURES.get("allAudio"):
        row4.append(InlineKeyboardButton("🎵 All Audio", callback_data="cballaudio"))
    if "allVideo" in user_features and FEATURES.get("allVideo"):
        row4.append(InlineKeyboardButton("🎥 All Video", callback_data="cballvideo"))
    if row4: buttons.append(row4)

    row5 = []
    if "allPdf" in user_features and FEATURES.get("allPdf"):
        row5.append(InlineKeyboardButton("📚 All PDFs", callback_data="cballpdf"))
    if row5: buttons.append(row5)

    row6 = []
    if "cookies" in user_features and FEATURES.get("cookies"):
        row6.append(InlineKeyboardButton("🍪 Cookies", callback_data="cbcookies"))
    if "localStorage" in user_features and FEATURES.get("localStorage"):
        row6.append(InlineKeyboardButton("📦 LocalStorage", callback_data="cblocalstorage"))
    if row6: buttons.append(row6)

    row7 = []
    if "metadata" in user_features and FEATURES.get("metadata"):
        row7.append(InlineKeyboardButton("📊 Metadata", callback_data="cbmetadata"))
    if row7: buttons.append(row7)

    row8 = []
    if "screenshot" in user_features and FEATURES.get("screenshot"):
        row8.append(InlineKeyboardButton("📷 Screenshot", callback_data="cbscreenshot"))
    if "screenRecord" in user_features and FEATURES.get("screenRecord"):
        row8.append(InlineKeyboardButton("🎬 Screen Record", callback_data="cbscreenrecord"))
    if row8: buttons.append(row8)

    row9 = []
    if "crawlWeb" in user_features and FEATURES.get("crawlWeb"):
        row9.append(InlineKeyboardButton("🕷️ Crawl Complete Web", callback_data="cbcrawl"))
    if row9: buttons.append(row9)

    # زر مقفل لو عنده ميزات أقل
    all_features = list(FEATURES.keys())
    locked = [f for f in all_features if f not in user_features and FEATURES.get(f)]
    if locked:
        buttons.append([InlineKeyboardButton("🔒 مميزات إضافية - اشترك /plans", callback_data="cbplans")])

    return InlineKeyboardMarkup(buttons)


# ==================== أزرار الباقات ====================
def get_plans_keyboard() -> InlineKeyboardMarkup:
    rows = []
    for key, plan in PLANS.items():
        price_text = "مجاني" if plan["price"] == 0 else f"${plan['price']}/{plan['period']}"
        rows.append([InlineKeyboardButton(
            f"{plan['name']} - {price_text}",
            callback_data=f"cbplan_{key}"
        )])
    rows.append([InlineKeyboardButton("🔙 رجوع", callback_data="cbback")])
    return InlineKeyboardMarkup(rows)


# ==================== نص عرض الباقات ====================
def get_plans_text() -> str:
    text = "📦 **الباقات المتاحة:**\n\n"
    for key, plan in PLANS.items():
        price_text = "مجاني" if plan["price"] == 0 else f"${plan['price']}/{plan['period']}"
        limit_text = "غير محدود" if plan["limit"] == -1 else f"{plan['limit']} طلب/يوم"
        text += f"**{plan['name']}** - {price_text} ({limit_text})\n"
        for f in plan["features"]:
            text += f"  {f}\n"
        text += "\n"
    text += "للاشتراك تواصل مع الدعم: /contact"
    return text
