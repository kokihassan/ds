# ============================================================
#  Proxy Manager - تدوير البروكسيات تلقائياً
# ============================================================

import os
import requests
import time
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# قراءة البروكسيات من .env
# PROXIES=http://user:pass@ip:port,http://ip2:port2,socks5://ip3:port3
_raw = os.getenv("PROXIES", "")
PROXY_LIST = [p.strip() for p in _raw.split(",") if p.strip()]
_current_index = 0
_failed_proxies = set()


def get_proxy() -> Optional[dict]:
    """يرجع البروكسي الحالي كـ dict مناسب لـ requests"""
    global _current_index
    if not PROXY_LIST:
        return None
    available = [p for p in PROXY_LIST if p not in _failed_proxies]
    if not available:
        # أعد تعيين المفشلة وجرب من جديد
        _failed_proxies.clear()
        available = PROXY_LIST
    proxy = available[_current_index % len(available)]
    return {"http": proxy, "https": proxy}


def mark_failed(proxy_dict: Optional[dict]):
    """علّم البروكسي الحالي كفاشل وانتقل للتالي"""
    global _current_index
    if not proxy_dict:
        return
    proxy_url = proxy_dict.get("http", "")
    if proxy_url:
        _failed_proxies.add(proxy_url)
        _current_index += 1
        logger.warning(f"[Proxy] فشل: {proxy_url}, الانتقال للتالي")


def rotate() -> Optional[dict]:
    """انتقل للبروكسي التالي"""
    global _current_index
    _current_index += 1
    return get_proxy()


def requests_get(url: str, **kwargs) -> requests.Response:
    """
    requests.get ذكي - يجرب البروكسيات تلقائياً
    لو البروكسي فشل ينتقل للتالي، لو كل البروكسيات فشلت يجرب بدون بروكسي
    """
    headers = kwargs.pop("headers", {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept-Language": "ar,en;q=0.9",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    })
    timeout = kwargs.pop("timeout", 15)

    if not PROXY_LIST:
        # بدون بروكسي مباشرة
        return requests.get(url, headers=headers, timeout=timeout, **kwargs)

    attempts = len(PROXY_LIST) + 1  # +1 للمحاولة بدون بروكسي
    for attempt in range(attempts):
        proxy = get_proxy() if attempt < len(PROXY_LIST) else None
        try:
            r = requests.get(url, headers=headers, timeout=timeout,
                             proxies=proxy, **kwargs)
            r.raise_for_status()
            return r
        except Exception as e:
            logger.warning(f"[Proxy attempt {attempt+1}] فشل: {e}")
            if proxy:
                mark_failed(proxy)
            time.sleep(0.5)

    raise Exception(f"فشلت كل المحاولات للوصول إلى: {url}")


def get_proxy_status() -> str:
    """تقرير حالة البروكسيات للأدمن"""
    if not PROXY_LIST:
        return "⚪ لا توجد بروكسيات مضبوطة (اتصال مباشر)"
    active  = [p for p in PROXY_LIST if p not in _failed_proxies]
    failed  = list(_failed_proxies)
    text    = f"🌐 **البروكسيات ({len(PROXY_LIST)} إجمالاً):**\n"
    text   += f"✅ فعّال: {len(active)}\n"
    text   += f"❌ فاشل: {len(failed)}\n\n"
    for p in PROXY_LIST:
        icon  = "✅" if p not in _failed_proxies else "❌"
        short = p[:40] + "..." if len(p) > 40 else p
        text += f"{icon} `{short}`\n"
    return text
