# ============================================================
#  WebScrapper Bot - لوحة التحكم الرئيسية
#  عدّل أي حاجة هنا وأعد تشغيل البوت
# ============================================================

# ==================== معلومات البوت ====================
BOT_NAME = "WebScrapper Bot"
BOT_USERNAME = "@WebScrapperBot"
SUPPORT_USERNAME = "@YourSupportUsername"   # ← غيّر ده

# ==================== رسالة الترحيب ====================
START_TEXT = """
👋 أهلاً بك في **WebScrapper Bot**!

🕷️ أنا بوت متخصص في استخراج البيانات من المواقع.

📌 **ما أقدر أعمله:**
• استخراج الروابط والصور والفيديوهات
• استخراج الصوت والـ PDF
• تصوير الشاشة وتسجيل الفيديو
• استخراج الكوكيز والـ Metadata
• تصدير البيانات بصيغ متعددة (CSV, JSON, TXT, Excel)
• زحف الموقع كامل

💡 **طريقة الاستخدام:**
فقط أرسل لي أي رابط وأنا هتكفل بالباقي!

📦 اكتب /plans لتعرف الباقات المتاحة
📞 اكتب /contact للتواصل مع الدعم
"""

# ==================== زر التواصل ====================
CONTACT_TEXT = """
📞 **تواصل مع الدعم الفني**

👨‍💻 **المطور:** {support}
🕐 **وقت الاستجابة:** خلال 24 ساعة
📧 **للشراكات والاستفسارات التجارية راسلنا مباشرة**

⚡ نحن هنا لمساعدتك!
""".format(support=SUPPORT_USERNAME)

# ==================== الباقات ====================
# limit = -1 يعني غير محدود
PLANS = {
    "free": {
        "name": "🆓 المجاني",
        "price": 0,
        "currency": "USD",
        "period": "شهري",
        "limit": 10,
        "ai_model": "groq",          # موديل AI لهذه الباقة
        "features": [
            "✅ استخراج الروابط",
            "✅ استخراج الفقرات",
            "✅ استخراج الصور (حتى 10)",
            "✅ تصدير CSV و TXT",
            "❌ الصوت والفيديو",
            "❌ تصوير الشاشة",
            "❌ زحف الموقع",
        ],
        "allowed_features": ["rawData", "htmlData", "allLinks", "allParagraphs", "allImages"],
        "export_formats": ["txt", "csv"],
    },
    "basic": {
        "name": "⭐ الأساسي",
        "price": 9.99,
        "currency": "USD",
        "period": "شهري",
        "limit": 100,
        "ai_model": "gemini",         # موديل AI لهذه الباقة
        "features": [
            "✅ كل المميزات المجانية",
            "✅ استخراج الصوت والفيديو",
            "✅ استخراج الـ PDF",
            "✅ الـ Metadata والكوكيز",
            "✅ تصدير CSV, JSON, TXT, Excel",
            "❌ تصوير الشاشة",
            "❌ زحف الموقع الكامل",
        ],
        "allowed_features": ["rawData", "htmlData", "allLinks", "allParagraphs", "allImages",
                             "allAudio", "allVideo", "allPdf", "metadata", "cookies", "localStorage"],
        "export_formats": ["txt", "csv", "json", "xlsx"],
    },
    "pro": {
        "name": "🚀 الاحترافي",
        "price": 24.99,
        "currency": "USD",
        "period": "شهري",
        "limit": -1,
        "ai_model": "openai",         # موديل AI لهذه الباقة
        "features": [
            "✅ كل المميزات الأساسية",
            "✅ تصوير الشاشة",
            "✅ تسجيل الشاشة فيديو",
            "✅ زحف الموقع الكامل",
            "✅ طلبات غير محدودة",
            "✅ تصدير بكل الصيغ + XML + Markdown",
            "✅ أولوية في الدعم",
        ],
        "allowed_features": ["rawData", "htmlData", "allLinks", "allParagraphs", "allImages",
                             "allAudio", "allVideo", "allPdf", "metadata", "cookies", "localStorage",
                             "screenshot", "screenRecord", "crawlWeb"],
        "export_formats": ["txt", "csv", "json", "xlsx", "xml", "md"],
    },
}

# ==================== إعدادات موديلات AI لكل باقة ====================
# يمكن تغييرها من لوحة التحكم مباشرة
PLAN_AI_MODELS = {
    "free":  "groq",      # groq | gemini | openai
    "basic": "gemini",
    "pro":   "openai",
}

# النماذج الفعلية لكل مزود
AI_MODEL_NAMES = {
    "groq":   "llama-3.3-70b-versatile",
    "gemini": "gemini-2.0-flash",
    "openai": "gpt-4o-mini",
}

# ==================== تفعيل / تعطيل المميزات ====================
FEATURES = {
    "rawData":       True,
    "htmlData":      True,
    "allLinks":      True,
    "allParagraphs": True,
    "allImages":     True,
    "allAudio":      True,
    "allVideo":      True,
    "allPdf":        True,
    "cookies":       True,
    "localStorage":  True,
    "metadata":      True,
    "screenshot":    True,
    "screenRecord":  True,
    "crawlWeb":      True,
    # ميزات التصدير
    "exportCSV":     True,
    "exportJSON":    True,
    "exportTXT":     True,
    "exportXLSX":    True,
    "exportXML":     True,
    "exportMarkdown":True,
}

# ==================== إعدادات إضافية للأدمن ====================
# وضع الصيانة - يمنع كل المستخدمين عدا الأدمن
MAINTENANCE_MODE = False
MAINTENANCE_MSG  = "🔧 البوت في وضع الصيانة حالياً، يرجى المحاولة لاحقاً."

# حد معدل الطلبات (ثواني بين كل طلب)
RATE_LIMIT_SECONDS = 3

# حجم الملف الأقصى للتحميل (MB)
MAX_FILE_SIZE_MB = 50

# تسجيل الطلبات في قاعدة البيانات
LOG_REQUESTS = True

# رسالة الترحيب الآلية للمستخدمين الجدد
AUTO_WELCOME = True

# ==================== إعدادات أخرى ====================
FINISHED_PROGRESS_STR   = "▓"
UN_FINISHED_PROGRESS_STR = "░"
REPO = "https://github.com/nuhmanpk/WebScrapper/"

# المشرفون (يملكون صلاحيات كاملة بغض النظر عن الاشتراك)
ADMINS = [123456789]   # ← غيّر ده لـ ID بتاعك
