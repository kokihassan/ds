# ============================================================
#  نظام الاشتراكات - SQLite Database
# ============================================================

import sqlite3
from datetime import datetime, timedelta
from config import PLANS

DB_FILE = "subscriptions.db"


def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS subscriptions (
            user_id     INTEGER PRIMARY KEY,
            username    TEXT,
            plan        TEXT    DEFAULT 'free',
            expiry      TEXT    DEFAULT NULL,
            daily_count INTEGER DEFAULT 0,
            last_reset  TEXT    DEFAULT NULL,
            is_banned   INTEGER DEFAULT 0,
            ban_reason  TEXT    DEFAULT NULL,
            created_at  TEXT    DEFAULT CURRENT_TIMESTAMP
        )
    """)
    # أضف الأعمدة الجديدة لو مش موجودة (للمشاريع القديمة)
    for col, typ in [("is_banned", "INTEGER DEFAULT 0"), ("ban_reason", "TEXT DEFAULT NULL")]:
        try:
            c.execute(f"ALTER TABLE subscriptions ADD COLUMN {col} {typ}")
        except:
            pass
    conn.commit()
    conn.close()


def get_user(user_id: int) -> dict:
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT * FROM subscriptions WHERE user_id=?", (user_id,))
    row = c.fetchone()
    conn.close()
    if row:
        return {
            "user_id": row[0], "username": row[1], "plan": row[2],
            "expiry": row[3], "daily_count": row[4],
            "last_reset": row[5], "is_banned": row[6],
            "ban_reason": row[7], "created_at": row[8],
        }
    return None


def register_user(user_id: int, username: str):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO subscriptions (user_id, username) VALUES (?, ?)", (user_id, username or ""))
    conn.commit()
    conn.close()


def set_plan(user_id: int, plan: str, days: int = 30):
    expiry = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d") if plan != "free" else None
    conn = sqlite3.connect(DB_FILE)
    conn.execute("UPDATE subscriptions SET plan=?, expiry=?, daily_count=0 WHERE user_id=?", (plan, expiry, user_id))
    conn.commit()
    conn.close()


def ban_user(user_id: int, reason: str = ""):
    conn = sqlite3.connect(DB_FILE)
    conn.execute("UPDATE subscriptions SET is_banned=1, ban_reason=? WHERE user_id=?", (reason, user_id))
    conn.commit()
    conn.close()


def unban_user(user_id: int):
    conn = sqlite3.connect(DB_FILE)
    conn.execute("UPDATE subscriptions SET is_banned=0, ban_reason=NULL WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()


def reset_user_usage(user_id: int):
    conn = sqlite3.connect(DB_FILE)
    conn.execute("UPDATE subscriptions SET daily_count=0 WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()


def is_plan_valid(user_id: int) -> bool:
    user = get_user(user_id)
    if not user or user["plan"] == "free":
        return True
    if not user["expiry"]:
        return True
    try:
        if datetime.now() > datetime.strptime(user["expiry"], "%Y-%m-%d"):
            conn = sqlite3.connect(DB_FILE)
            conn.execute("UPDATE subscriptions SET plan='free', expiry=NULL WHERE user_id=?", (user_id,))
            conn.commit()
            conn.close()
            return False
    except:
        pass
    return True


def can_use(user_id: int):
    user = get_user(user_id)
    if not user:
        return False, "مش مسجل"
    if user.get("is_banned"):
        reason = user.get("ban_reason") or "لا يوجد سبب"
        return False, f"🚫 تم حظرك\nالسبب: {reason}"
    if not is_plan_valid(user_id):
        return False, "انتهى اشتراكك ❌\n\nاشترك من جديد عبر /plans"
    plan  = PLANS.get(user["plan"], PLANS["free"])
    limit = plan["limit"]
    if limit == -1:
        return True, ""
    today       = datetime.now().strftime("%Y-%m-%d")
    last_reset  = user.get("last_reset", "")
    daily_count = user.get("daily_count", 0)
    if last_reset != today:
        conn = sqlite3.connect(DB_FILE)
        conn.execute("UPDATE subscriptions SET daily_count=0, last_reset=? WHERE user_id=?", (today, user_id))
        conn.commit()
        conn.close()
        daily_count = 0
    if daily_count >= limit:
        return False, f"⚠️ وصلت للحد اليومي ({limit} طلب)\n\n⬆️ رفّع باقتك عبر /plans"
    return True, ""


def increment_usage(user_id: int):
    today = datetime.now().strftime("%Y-%m-%d")
    conn  = sqlite3.connect(DB_FILE)
    c     = conn.cursor()
    c.execute("SELECT last_reset, daily_count FROM subscriptions WHERE user_id=?", (user_id,))
    row = c.fetchone()
    if row:
        last_reset, daily_count = row
        if last_reset != today:
            daily_count = 0
        c.execute("UPDATE subscriptions SET daily_count=?, last_reset=? WHERE user_id=?",
                  (daily_count + 1, today, user_id))
    conn.commit()
    conn.close()


def can_use_feature(user_id: int, feature: str) -> bool:
    user = get_user(user_id)
    if not user:
        return False
    plan_key = user["plan"] if is_plan_valid(user_id) else "free"
    return feature in PLANS.get(plan_key, PLANS["free"])["allowed_features"]


def get_all_users():
    conn = sqlite3.connect(DB_FILE)
    c    = conn.cursor()
    c.execute("SELECT user_id, username, plan, expiry, daily_count, is_banned, created_at FROM subscriptions ORDER BY created_at DESC")
    rows = c.fetchall()
    conn.close()
    return rows


def get_stats():
    conn  = sqlite3.connect(DB_FILE)
    c     = conn.cursor()
    total = c.execute("SELECT COUNT(*) FROM subscriptions").fetchone()[0]
    today = datetime.now().strftime("%Y-%m-%d")
    active_today = c.execute("SELECT COUNT(*) FROM subscriptions WHERE last_reset=? AND daily_count>0", (today,)).fetchone()[0]
    banned = c.execute("SELECT COUNT(*) FROM subscriptions WHERE is_banned=1").fetchone()[0]
    by_plan = c.execute("SELECT plan, COUNT(*) FROM subscriptions GROUP BY plan").fetchall()
    conn.close()
    return {"total": total, "active_today": active_today, "banned": banned, "by_plan": dict(by_plan)}


init_db()
