# ============================================================
#  AI Assistant - مع دعم اختيار الموديل لكل باقة
# ============================================================

import os
import requests
from bs4 import BeautifulSoup
from proxy_manager import requests_get
import logging
import config

logger = logging.getLogger(__name__)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GROQ_API_KEY   = os.getenv("GROQ_API_KEY",   "")

GEMINI_MODELS = [
    "gemini-2.0-flash",
    "gemini-1.5-flash-latest",
    "gemini-1.5-flash-8b",
    "gemini-1.0-pro",
]
GEMINI_BASE = "https://generativelanguage.googleapis.com/v1/models/{model}:generateContent"

GROQ_URL   = "https://api.groq.com/openai/v1/chat/completions"
OPENAI_URL = "https://api.openai.com/v1/chat/completions"

GROQ_MODELS = [
    "llama-3.3-70b-versatile",
    "llama-3.1-8b-instant",
    "mixtral-8x7b-32768",
    "gemma2-9b-it",
]

SYSTEM_PROMPT = """أنت مساعد ذكي داخل بوت تيليجرام متخصص في استخراج البيانات من المواقع.

المستخدم سيعطيك محتوى صفحة ويب وطلبه بالكلام الطبيعي.

قواعد الإجابة:
- روابط → قائمة منظمة
- أسعار → مع اسم المنتج والعملة
- تواصل → إيميل / تليفون / عنوان / سوشيال
- ملخص → 5 نقاط رئيسية
- جداول → منسقة بوضوح
- لو البيانات كتيرة → أهم 10 نتائج فقط
- أجب بالعربي دائماً إلا لو طُلب غير ذلك
- كن دقيقاً ومختصراً
"""

QUICK_PROMPTS = {
    "summary":   "لخّص هذه الصفحة في 5 نقاط رئيسية واضحة",
    "prices":    "استخرج كل الأسعار مع اسم المنتج/الخدمة والعملة",
    "contacts":  "استخرج بيانات التواصل: إيميل، تليفون، عنوان، سوشيال ميديا",
    "products":  "استخرج قائمة المنتجات أو الخدمات مع أسعارها إن وجدت",
    "news":      "استخرج عناوين الأخبار أو المقالات الرئيسية",
    "emails":    "استخرج كل عناوين الإيميل فقط",
    "phones":    "استخرج كل أرقام الهواتف فقط",
    "social":    "استخرج روابط السوشيال ميديا كلها",
    "tables":    "استخرج البيانات الجدولية ورتّبها",
    "addresses": "استخرج كل العناوين الجغرافية",
    "keywords":  "استخرج أهم الكلمات المفتاحية في الصفحة",
    "headings":  "استخرج كل العناوين والترويسات الرئيسية",
    "videos":    "اذكر كل محتوى الفيديو المذكور في الصفحة",
    "authors":   "استخرج أسماء الكتّاب أو المؤلفين",
    "dates":     "استخرج كل التواريخ والمواعيد الموجودة",
}


# ══════════════════════════════════════════════════════════════
#  سحب محتوى الصفحة
# ══════════════════════════════════════════════════════════════

def scrape_page(url: str, extra_headers: dict = None) -> tuple:
    try:
        headers = {
            "User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
            "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Cache-Control":   "no-cache",
            "Cookie":          "cookieconsent_status=allow; gdpr=1; cookie_consent=accepted; CONSENT=YES+",
        }
        if extra_headers:
            headers.update(extra_headers)
        resp = requests_get(url, headers=headers, timeout=20)
        soup = BeautifulSoup(resp.content, "html.parser")
        for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
            tag.decompose()
        text = soup.get_text(separator="\n", strip=True)
        text = "\n".join(line for line in text.splitlines() if line.strip())
        return text[:12000], None
    except Exception as e:
        logger.error(f"[scrape_page] {e}")
        return "", str(e)


# ══════════════════════════════════════════════════════════════
#  الحصول على موديل AI لباقة معينة
# ══════════════════════════════════════════════════════════════

def get_model_for_plan(plan_key: str) -> str:
    """يرجع اسم مزود AI المحدد لهذه الباقة"""
    return config.PLAN_AI_MODELS.get(plan_key, "groq")


# ══════════════════════════════════════════════════════════════
#  استدعاء AI بناءً على المزود
# ══════════════════════════════════════════════════════════════

async def call_ai(messages: list, provider: str = "groq") -> str:
    """يستدعي AI المناسب حسب المزود"""

    if provider == "openai" and OPENAI_API_KEY:
        return await _call_openai(messages)
    elif provider == "gemini" and GEMINI_API_KEY:
        return await _call_gemini(messages)
    elif provider == "groq" and GROQ_API_KEY:
        return await _call_groq(messages)
    else:
        # fallback: جرّب كل المتاح
        if OPENAI_API_KEY:
            return await _call_openai(messages)
        if GEMINI_API_KEY:
            return await _call_gemini(messages)
        if GROQ_API_KEY:
            return await _call_groq(messages)
        return "⚠️ لم يتم إعداد أي مفتاح AI، يرجى إضافة OPENAI_API_KEY أو GEMINI_API_KEY أو GROQ_API_KEY في ملف .env"


async def _call_groq(messages: list) -> str:
    model_name = config.AI_MODEL_NAMES.get("groq", "llama-3.3-70b-versatile")
    for model in [model_name] + GROQ_MODELS:
        try:
            resp = requests.post(
                GROQ_URL,
                headers={"Authorization": f"Bearer {GROQ_API_KEY}", "Content-Type": "application/json"},
                json={"model": model, "messages": messages, "max_tokens": 2000, "temperature": 0.3},
                timeout=30
            )
            data = resp.json()
            if "choices" in data:
                return data["choices"][0]["message"]["content"].strip()
        except Exception as e:
            logger.warning(f"[Groq:{model}] {e}")
    return "⚠️ فشل الاتصال بـ Groq AI"


async def _call_gemini(messages: list) -> str:
    model_name = config.AI_MODEL_NAMES.get("gemini", "gemini-2.0-flash")
    system_msg = next((m["content"] for m in messages if m["role"] == "system"), "")
    user_msgs  = [m for m in messages if m["role"] != "system"]
    prompt     = (system_msg + "\n\n" if system_msg else "") + "\n".join(
        f"{'المستخدم' if m['role']=='user' else 'المساعد'}: {m['content']}" for m in user_msgs
    )
    for model in [model_name] + GEMINI_MODELS:
        try:
            url  = GEMINI_BASE.format(model=model)
            resp = requests.post(
                f"{url}?key={GEMINI_API_KEY}",
                json={"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"maxOutputTokens": 2000}},
                timeout=30
            )
            data = resp.json()
            if "candidates" in data:
                return data["candidates"][0]["content"]["parts"][0]["text"].strip()
        except Exception as e:
            logger.warning(f"[Gemini:{model}] {e}")
    return "⚠️ فشل الاتصال بـ Gemini AI"


async def _call_openai(messages: list) -> str:
    model_name = config.AI_MODEL_NAMES.get("openai", "gpt-4o-mini")
    try:
        resp = requests.post(
            OPENAI_URL,
            headers={"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"},
            json={"model": model_name, "messages": messages, "max_tokens": 2000, "temperature": 0.3},
            timeout=30
        )
        data = resp.json()
        if "choices" in data:
            return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logger.error(f"[OpenAI] {e}")
    return "⚠️ فشل الاتصال بـ OpenAI"


# ══════════════════════════════════════════════════════════════
#  الدوال الرئيسية
# ══════════════════════════════════════════════════════════════

async def ask_ai(url: str, question: str, history: list = None, plan_key: str = "free") -> str:
    page_text, err = scrape_page(url)
    if err or not page_text:
        return f"⚠️ تعذّر قراءة الصفحة: {err or 'محتوى فارغ'}"

    provider = get_model_for_plan(plan_key)
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages.append({"role": "user", "content": f"محتوى الصفحة:\n{page_text}"})
    messages.append({"role": "assistant", "content": "تم تحميل الصفحة. ماذا تريد استخراجه؟"})
    if history:
        messages.extend(history[-10:])
    messages.append({"role": "user", "content": question})
    return await call_ai(messages, provider)


async def quick_extract(url: str, extract_type: str, plan_key: str = "free") -> str:
    page_text, err = scrape_page(url)
    if err or not page_text:
        return f"⚠️ تعذّر قراءة الصفحة: {err or 'محتوى فارغ'}"

    prompt   = QUICK_PROMPTS.get(extract_type, f"استخرج {extract_type} من الصفحة")
    provider = get_model_for_plan(plan_key)
    messages = [
        {"role": "system",    "content": SYSTEM_PROMPT},
        {"role": "user",      "content": f"محتوى الصفحة:\n{page_text}\n\nالطلب: {prompt}"},
    ]
    return await call_ai(messages, provider)


# ══════════════════════════════════════════════════════════════
#  معلومات حالة AI
# ══════════════════════════════════════════════════════════════

def get_ai_status() -> str:
    lines = ["🤖 **حالة مزودي AI:**\n━━━━━━━━━━━━━━━\n"]

    # OpenAI
    if OPENAI_API_KEY:
        model = config.AI_MODEL_NAMES.get("openai", "gpt-4o-mini")
        lines.append(f"✅ **OpenAI** — موديل: `{model}`")
    else:
        lines.append("❌ **OpenAI** — غير مُعدّ (OPENAI_API_KEY فارغ)")

    # Gemini
    if GEMINI_API_KEY:
        model = config.AI_MODEL_NAMES.get("gemini", "gemini-2.0-flash")
        lines.append(f"✅ **Gemini** — موديل: `{model}`")
    else:
        lines.append("❌ **Gemini** — غير مُعدّ (GEMINI_API_KEY فارغ)")

    # Groq
    if GROQ_API_KEY:
        model = config.AI_MODEL_NAMES.get("groq", "llama-3.3-70b-versatile")
        lines.append(f"✅ **Groq** — موديل: `{model}`")
    else:
        lines.append("❌ **Groq** — غير مُعدّ (GROQ_API_KEY فارغ)")

    lines.append("\n📦 **موديل AI لكل باقة:**")
    for plan_key, provider in config.PLAN_AI_MODELS.items():
        plan_name = config.PLANS.get(plan_key, {}).get("name", plan_key)
        lines.append(f"  {plan_name} → **{provider}** ({config.AI_MODEL_NAMES.get(provider, '?')})")

    return "\n".join(lines)
