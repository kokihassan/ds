# ============================================================
#  Export Handler - تصدير البيانات بصيغ متعددة
# ============================================================

import io
import json
import csv
import os
import logging
from datetime import datetime
from config import PLANS

logger = logging.getLogger(__name__)

EXPORT_LABELS = {
    "txt":  "📄 Text (.txt)",
    "csv":  "📊 CSV (.csv)",
    "json": "🗂️ JSON (.json)",
    "xlsx": "📗 Excel (.xlsx)",
    "xml":  "📋 XML (.xml)",
    "md":   "📝 Markdown (.md)",
}


def get_export_keyboard(data_key: str, user_plan: str = "free"):
    """يبني كيبورد أزرار التصدير بناءً على باقة المستخدم"""
    from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    from config import FEATURES

    plan      = PLANS.get(user_plan, PLANS["free"])
    allowed   = plan.get("export_formats", ["txt", "csv"])
    all_fmts  = ["txt", "csv", "json", "xlsx", "xml", "md"]

    rows = []
    row  = []
    for fmt in all_fmts:
        feature_key = f"export{fmt.upper()}" if fmt != "md" else "exportMarkdown"
        if fmt in allowed and FEATURES.get(feature_key, True):
            label = EXPORT_LABELS[fmt]
            row.append(InlineKeyboardButton(label, callback_data=f"cbexport_{data_key}_{fmt}"))
        else:
            row.append(InlineKeyboardButton(f"🔒 {EXPORT_LABELS[fmt]}", callback_data="cbplans"))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton("❌ إلغاء", callback_data="cbback")])
    return InlineKeyboardMarkup(rows)


def export_links(links: list, fmt: str, url: str = "") -> tuple:
    """تصدير الروابط"""
    return _export_list(links, fmt, "links", url, headers=["URL"])


def export_paragraphs(paragraphs: list, fmt: str, url: str = "") -> tuple:
    """تصدير الفقرات"""
    return _export_list(paragraphs, fmt, "paragraphs", url, headers=["Text"])


def export_metadata(metadata: dict, fmt: str, url: str = "") -> tuple:
    """تصدير الـ metadata"""
    items = [{"key": k, "value": str(v)} for k, v in metadata.items()]
    return _export_dicts(items, fmt, "metadata", url, headers=["key", "value"])


def export_cookies(cookies: list, fmt: str, url: str = "") -> tuple:
    """تصدير الكوكيز"""
    if cookies and isinstance(cookies[0], dict):
        headers = list(cookies[0].keys())
        return _export_dicts(cookies, fmt, "cookies", url, headers=headers)
    return _export_list([str(c) for c in cookies], fmt, "cookies", url, headers=["Cookie"])


def export_raw_text(text: str, fmt: str, url: str = "") -> tuple:
    """تصدير النص الخام"""
    lines = [{"line": i+1, "text": line} for i, line in enumerate(text.split("\n")) if line.strip()]
    if fmt == "txt":
        return _make_txt(text, "rawdata", url)
    return _export_dicts(lines, fmt, "rawdata", url, headers=["line", "text"])


def _export_list(items: list, fmt: str, name: str, url: str = "", headers: list = None) -> tuple:
    headers = headers or ["value"]
    dicts   = [{headers[0]: item} for item in items]
    return _export_dicts(dicts, fmt, name, url, headers=headers)


def _export_dicts(items: list, fmt: str, name: str, url: str = "", headers: list = None) -> tuple:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename  = f"{name}_{timestamp}.{fmt}"
    headers   = headers or (list(items[0].keys()) if items else ["value"])

    try:
        if fmt == "txt":
            content = f"# {name.upper()} - {url}\n# تاريخ التصدير: {timestamp}\n# عدد العناصر: {len(items)}\n\n"
            content += "\n".join(str(list(item.values())[0]) if len(item) == 1 else " | ".join(str(v) for v in item.values()) for item in items)
            return filename, content.encode("utf-8"), "text/plain"

        elif fmt == "csv":
            buf = io.StringIO()
            w   = csv.DictWriter(buf, fieldnames=headers, extrasaction="ignore")
            w.writeheader()
            w.writerows(items)
            return filename, buf.getvalue().encode("utf-8"), "text/csv"

        elif fmt == "json":
            data = {
                "source":    url,
                "exported":  timestamp,
                "count":     len(items),
                "data":      items,
            }
            return filename, json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"), "application/json"

        elif fmt == "xlsx":
            try:
                import openpyxl
                from openpyxl.styles import Font, PatternFill, Alignment
                wb = openpyxl.Workbook()
                ws = wb.active
                ws.title = name[:30]

                # Header row styling
                header_fill = PatternFill("solid", fgColor="1F4E79")
                header_font = Font(bold=True, color="FFFFFF")
                for col_idx, h in enumerate(headers, 1):
                    cell = ws.cell(row=1, column=col_idx, value=h)
                    cell.fill  = header_fill
                    cell.font  = header_font
                    cell.alignment = Alignment(horizontal="center")

                # Data rows
                for row_idx, item in enumerate(items, 2):
                    for col_idx, h in enumerate(headers, 1):
                        ws.cell(row=row_idx, column=col_idx, value=str(item.get(h, "")))

                # Auto column width
                for col in ws.columns:
                    max_len = max((len(str(cell.value or "")) for cell in col), default=10)
                    ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 60)

                # Metadata sheet
                ws2 = wb.create_sheet("Info")
                ws2["A1"], ws2["B1"] = "المصدر", url
                ws2["A2"], ws2["B2"] = "تاريخ التصدير", timestamp
                ws2["A3"], ws2["B3"] = "عدد العناصر", len(items)

                buf = io.BytesIO()
                wb.save(buf)
                return filename, buf.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            except ImportError:
                # fallback to CSV
                return _export_dicts(items, "csv", name, url, headers)

        elif fmt == "xml":
            lines = ['<?xml version="1.0" encoding="UTF-8"?>',
                     f'<export source="{url}" timestamp="{timestamp}" count="{len(items)}">']
            for item in items:
                lines.append(f"  <item>")
                for k, v in item.items():
                    safe_v = str(v).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"','&quot;')
                    lines.append(f"    <{k}>{safe_v}</{k}>")
                lines.append(f"  </item>")
            lines.append("</export>")
            return filename, "\n".join(lines).encode("utf-8"), "application/xml"

        elif fmt == "md":
            lines = [f"# {name.upper()}", f"", f"**المصدر:** {url}", f"**التاريخ:** {timestamp}", f"**العناصر:** {len(items)}", ""]
            # Table header
            lines.append("| " + " | ".join(headers) + " |")
            lines.append("| " + " | ".join(["---"] * len(headers)) + " |")
            for item in items:
                row = "| " + " | ".join(str(item.get(h, "")) for h in headers) + " |"
                lines.append(row)
            return filename, "\n".join(lines).encode("utf-8"), "text/markdown"

    except Exception as e:
        logger.error(f"[export] {e}")
        # Fallback to TXT
        content = "\n".join(str(item) for item in items)
        return f"{name}_{timestamp}.txt", content.encode("utf-8"), "text/plain"

    return filename, b"", "text/plain"


def _make_txt(text: str, name: str, url: str) -> tuple:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    content   = f"# {name.upper()} - {url}\n# تاريخ التصدير: {timestamp}\n\n{text}"
    return f"{name}_{timestamp}.txt", content.encode("utf-8"), "text/plain"
