# ============================================================
#  Scraper - مع تحسين رسائل الأخطاء + تفعيل Screenshot
# ============================================================

import asyncio
import time
import requests
import os
import shutil
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram import enums
from bs4 import BeautifulSoup
from urllib.parse import quote
from config import REPO
from helpers import (
    download_image, download_media, download_pdf,
    init_headless_browser, progress_bar, progress_for_pyrogram
)
import imageio


# ─────────────────────── Helper ───────────────────────────────
async def scrape(url):
    try:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        request = requests.get(url, headers=headers, timeout=15)
        soup    = BeautifulSoup(request.content, "html5lib")
        return request, soup
    except requests.exceptions.ConnectionError:
        return None, None
    except requests.exceptions.Timeout:
        return None, None
    except Exception:
        return None, None


def error_markup(e: Exception) -> tuple:
    error      = f"ERROR: {str(e)}"
    error_link = f"{REPO}/issues/new?title={quote(error)}"
    text = (
        "⚠️ **حدث خطأ أثناء المعالجة**\n\n"
        f"**السبب:** `{str(e)[:200]}`\n\n"
        "يمكنك الإبلاغ عن المشكلة أو المحاولة مرة أخرى."
    )
    markup = InlineKeyboardMarkup([[
        InlineKeyboardButton("🐛 الإبلاغ عن خطأ", url=error_link)
    ]])
    return text, markup


async def check_url(message, url) -> bool:
    """يتحقق من الرابط قبل البدء"""
    req, soup = await scrape(url)
    if req is None:
        await message.reply_text(
            "❌ **تعذّر الوصول إلى الرابط**\n\n"
            "• تأكد أن الرابط صحيح ومتاح\n"
            "• قد يكون الموقع محجوب أو بطيء\n"
            "• حاول مرة أخرى بعد قليل",
            quote=True
        )
        return False
    return True


# ─────────────────────── Raw Data ─────────────────────────────
async def raw_data_scraping(query, update_data_fn=None):
    message = query.message
    url     = message.text
    fname   = f"RawData-{message.chat.id}.txt"
    try:
        if not await check_url(message, url): return
        request, soup = await scrape(url)
        raw_text = str(request.content)
        with open(fname, "w", encoding="utf-8") as f:
            f.write(raw_text)
        # حفظ البيانات في الـ cache قبل الإرسال
        if update_data_fn:
            update_data_fn(message.chat.id, "cache_rawdata", raw_text)
        await message.reply_document(fname, caption="📄 Raw Data\n@Scraping_data_bot", quote=True)
        await asyncio.sleep(1)
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)
    finally:
        if os.path.exists(fname): os.remove(fname)


# ─────────────────────── HTML Data ────────────────────────────
async def html_data_scraping(query, update_data_fn=None):
    message = query.message
    url     = message.text
    fname   = f"HtmlData-{message.chat.id}.txt"
    try:
        if not await check_url(message, url): return
        request, soup = await scrape(url)
        html_text = soup.prettify()
        with open(fname, "w", encoding="utf-8") as f:
            f.write(html_text)
        if update_data_fn:
            update_data_fn(message.chat.id, "cache_rawdata", html_text)
        await message.reply_document(fname, caption="📝 HTML Data\n@Scraping_data_bot", quote=True)
        await asyncio.sleep(1)
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)
    finally:
        if os.path.exists(fname): os.remove(fname)


# ─────────────────────── All Links ────────────────────────────
async def all_links_scraping(query, update_data_fn=None):
    message = query.message
    url     = message.text
    fname   = f"AllLinks-{message.chat.id}.txt"
    try:
        if not await check_url(message, url): return
        request, soup = await scrape(url)
        links = [link.get("href") for link in soup.find_all("a") if link.get("href")]
        if not links:
            return await message.reply_text("🔍 لم يتم العثور على روابط في هذه الصفحة.", quote=True)
        if update_data_fn:
            update_data_fn(message.chat.id, "cache_links", links)
        with open(fname, "w", encoding="utf-8") as f:
            f.write(f"إجمالي الروابط: {len(links)}\n\n")
            f.write("\n\n".join(links))
        await message.reply_document(fname, caption=f"🔗 تم العثور على {len(links)} رابط\n@Scraping_data_bot", quote=True)
        await asyncio.sleep(1)
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)
    finally:
        if os.path.exists(fname): os.remove(fname)


# ─────────────────────── Paragraphs ───────────────────────────
async def all_paragraph_scraping(query, update_data_fn=None):
    message = query.message
    url     = message.text
    fname   = f"AllParagraph-{message.chat.id}.txt"
    try:
        if not await check_url(message, url): return
        request, soup = await scrape(url)
        paragraphs = [p.get_text().strip() for p in soup.find_all("p") if p.get_text().strip()]
        if not paragraphs:
            return await message.reply_text("🔍 لم يتم العثور على فقرات نصية.", quote=True)
        if update_data_fn:
            update_data_fn(message.chat.id, "cache_paragraphs", paragraphs)
        with open(fname, "w", encoding="utf-8") as f:
            f.write(f"إجمالي الفقرات: {len(paragraphs)}\n\n")
            f.write("\n\n".join(paragraphs))
        await message.reply_document(fname, caption=f"📃 تم العثور على {len(paragraphs)} فقرة\n@Scraping_data_bot", quote=True)
        await asyncio.sleep(1)
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)
    finally:
        if os.path.exists(fname): os.remove(fname)


# ─────────────────────── Images ───────────────────────────────
async def all_images_scraping(bot, query):
    message = query.message
    chat_id = message.chat.id
    folder  = f"{chat_id}-images"
    zip_f   = f"{folder}.zip"
    try:
        if not await check_url(message, message.text): return
        txt = await message.reply_text("⏳ جاري فحص الصفحة...", quote=True)
        request, soup = await scrape(message.text)
        image_links = [img.get("src") for img in soup.find_all("img") if img.get("src")]

        if not image_links:
            return await txt.edit("🔍 لم يتم العثور على صور في هذه الصفحة.")

        await txt.edit(f"🌄 تم العثور على {len(image_links)} صورة\nجاري التحميل...")
        status = await message.reply_text("⬇️ جاري التحميل...", quote=True)
        os.makedirs(folder, exist_ok=True)

        downloaded = 0
        for idx, image_link in enumerate(image_links):
            image_data = await download_image(message.text, image_link, idx)
            if image_data:
                with open(f"{folder}/image{idx}.jpg", "wb") as f:
                    f.write(image_data)
                downloaded += 1
            progress, pct = await progress_bar(idx + 1, len(image_links))
            try: await status.edit(f"⬇️ {pct}% | {progress}\nتم تحميل {downloaded}/{len(image_links)}")
            except: pass

        if downloaded == 0:
            return await status.edit("❌ تعذّر تحميل أي صورة. قد تكون الصور محمية.")

        await status.edit("📦 جاري الضغط والرفع...")
        shutil.make_archive(folder, "zip", folder)
        c_time = time.time()
        await bot.send_chat_action(chat_id, enums.ChatAction.UPLOAD_DOCUMENT)
        await message.reply_document(
            open(zip_f, "rb"),
            caption=f"🌄 {downloaded} صورة\n@Scraping_data_bot",
            progress=progress_for_pyrogram,
            progress_args=("⬆️ رفع", status, c_time)
        )
        await status.delete()
        await txt.delete()
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)
    finally:
        if os.path.exists(folder): shutil.rmtree(folder)
        if os.path.exists(zip_f): os.remove(zip_f)


# ─────────────────────── Audio ────────────────────────────────
async def all_audio_scraping(bot, query):
    message = query.message
    chat_id = message.chat.id
    folder  = f"{chat_id}-audios"
    zip_f   = f"{folder}.zip"
    try:
        if not await check_url(message, message.text): return
        txt = await message.reply_text("⏳ جاري فحص الصفحة...", quote=True)
        request, soup = await scrape(message.text)
        audio_links = [a.get("src") for a in soup.find_all("audio") if a.get("src")]
        if not audio_links:
            return await txt.edit("🔍 لم يتم العثور على ملفات صوتية.")
        await txt.edit(f"🎵 تم العثور على {len(audio_links)} ملف صوتي")
        status = await message.reply_text("⬇️ جاري التحميل...", quote=True)
        os.makedirs(folder, exist_ok=True)
        for idx, link in enumerate(audio_links):
            data = await download_media(message.text, link, idx, "audio")
            if data:
                media_data, fname = data
                with open(f"{folder}/audio{idx}.mp3", "wb") as f:
                    f.write(media_data)
            progress, pct = await progress_bar(idx + 1, len(audio_links))
            try: await status.edit(f"⬇️ {pct}% | {progress}")
            except: pass
        await status.edit("📦 جاري الضغط والرفع...")
        shutil.make_archive(folder, "zip", folder)
        c_time = time.time()
        await bot.send_chat_action(chat_id, enums.ChatAction.UPLOAD_AUDIO)
        await message.reply_document(open(zip_f, "rb"), caption=f"🎵 {len(audio_links)} ملف صوتي\n@Scraping_data_bot",
                                     progress=progress_for_pyrogram, progress_args=("⬆️ رفع", status, c_time))
        await status.delete()
        await txt.delete()
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)
    finally:
        if os.path.exists(folder): shutil.rmtree(folder)
        if os.path.exists(zip_f): os.remove(zip_f)


# ─────────────────────── Video ────────────────────────────────
async def all_video_scraping(bot, query):
    message    = query.message
    chat_id    = message.chat.id
    folder     = f"{chat_id}-videos"
    zip_f      = f"{folder}.zip"
    try:
        if not await check_url(message, message.text): return
        txt = await message.reply_text("⏳ جاري فحص الصفحة...", quote=True)
        request, soup = await scrape(message.text)
        video_tags  = soup.find_all("video")
        video_links = []
        for v in video_tags:
            if v.has_attr("src"):
                video_links.append(v["src"])
            elif v.find("source"):
                video_links.append(v.find("source")["src"])
        if not video_links:
            return await txt.edit("🔍 لم يتم العثور على فيديوهات.")
        await txt.edit(f"🎥 تم العثور على {len(video_links)} فيديو")
        status = await message.reply_text("⬇️ جاري التحميل...", quote=True)
        os.makedirs(folder, exist_ok=True)
        for idx, link in enumerate(video_links):
            result = await download_media(message.text, link, idx, "video")
            if result:
                video_data, local_fname = result
                with open(os.path.join(folder, local_fname), "wb") as f:
                    f.write(video_data)
            progress, pct = await progress_bar(idx + 1, len(video_links))
            try: await status.edit(f"⬇️ {pct}% | {progress}")
            except: pass
            time.sleep(0.3)
        await status.edit("📦 جاري الضغط والرفع...")
        shutil.make_archive(folder, "zip", folder)
        c_time = time.time()
        await bot.send_chat_action(chat_id, enums.ChatAction.UPLOAD_VIDEO)
        await message.reply_document(open(zip_f, "rb"), caption=f"🎥 {len(video_links)} فيديو\n@Scraping_data_bot",
                                     progress=progress_for_pyrogram, progress_args=("⬆️ رفع", status, c_time))
        await status.delete()
        await txt.delete()
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)
    finally:
        if os.path.exists(folder): shutil.rmtree(folder)
        if os.path.exists(zip_f): os.remove(zip_f)


# ─────────────────────── PDF ──────────────────────────────────
async def all_pdf_scraping(query):
    message = query.message
    folder  = f"{message.chat.id}-pdfs"
    zip_f   = f"{folder}.zip"
    try:
        if not await check_url(message, message.text): return
        txt = await message.reply_text("⏳ جاري فحص الصفحة...", quote=True)
        request, soup = await scrape(message.text)
        pdf_links = [a["href"] for a in soup.find_all("a", href=True) if a["href"].endswith(".pdf")]
        if not pdf_links:
            return await txt.edit("🔍 لم يتم العثور على ملفات PDF.")
        await txt.edit(f"📚 تم العثور على {len(pdf_links)} PDF")
        status = await message.reply_text("⬇️ جاري التحميل...", quote=True)
        os.makedirs(folder, exist_ok=True)
        for idx, link in enumerate(pdf_links):
            pdf_data = await download_pdf(message.text, link, idx, "pdf")
            if pdf_data:
                fname = os.path.basename(link) or f"file{idx}.pdf"
                with open(os.path.join(folder, fname), "wb") as f:
                    f.write(pdf_data)
            progress, pct = await progress_bar(idx + 1, len(pdf_links))
            try: await status.edit(f"⬇️ {pct}% | {progress}")
            except: pass
            time.sleep(0.3)
        await status.edit("📦 جاري الضغط والرفع...")
        shutil.make_archive(folder, "zip", folder)
        await message.reply_document(open(zip_f, "rb"), caption=f"📚 {len(pdf_links)} ملف PDF\n@Scraping_data_bot")
        await status.delete()
        await txt.delete()
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)
    finally:
        if os.path.exists(folder): shutil.rmtree(folder)
        if os.path.exists(zip_f): os.remove(zip_f)


# ─────────────────────── Metadata ─────────────────────────────
async def extract_metadata(query, update_data_fn=None):
    message = query.message
    try:
        if not await check_url(message, message.text): return
        txt = await message.reply_text("⏳ جاري الاستخراج...", quote=True)
        request, soup = await scrape(message.text)
        title       = soup.title.string.strip() if soup.title else "غير متاح"
        description = (soup.find("meta", attrs={"name": "description"}) or {}).get("content", "غير متاح")
        keywords    = (soup.find("meta", attrs={"name": "keywords"}) or {}).get("content", "غير متاح")
        og_image    = (soup.find("meta", attrs={"property": "og:image"}) or {}).get("content", "غير متاح")
        metadata_dict = {
            "title": title,
            "description": description,
            "keywords": keywords,
            "og_image": og_image,
        }
        if update_data_fn:
            update_data_fn(message.chat.id, "cache_metadata", metadata_dict)
        text = (
            f"📊 **Metadata:**\n\n"
            f"**📌 العنوان:** {title}\n"
            f"**📝 الوصف:** {description}\n"
            f"**🔑 الكلمات المفتاحية:** {keywords}\n"
            f"**🖼️ صورة OG:** {og_image}"
        )
        await message.reply_text(text)
        await txt.delete()
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)


# ─────────────────────── Cookies ──────────────────────────────
async def extract_cookies(query, update_data_fn=None):
    message = query.message
    chat_id = message.chat.id
    fname   = f"Cookies-{chat_id}.txt"
    try:
        txt    = await message.reply_text("🌐 جاري تشغيل المتصفح...", quote=True)
        driver = await init_headless_browser(message.text)
        if not driver:
            return await txt.edit("❌ تعذّر تشغيل المتصفح. تأكد من تثبيت Chrome أو Firefox.")
        await txt.edit("🍪 جاري قبول الكوكيز...")
        # محاولة قبول الكوكيز تلقائياً قبل الاستخراج
        try:
            from selenium.webdriver.common.by import By
            import time as _time
            _time.sleep(2)  # انتظر تحميل الصفحة
            # البحث عن أزرار قبول الكوكيز الشائعة
            accept_selectors = [
                "//button[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'accept')]",
                "//button[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'agree')]",
                "//button[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'allow')]",
                "//button[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'موافق')]",
                "//button[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'قبول')]",
                "//*[@id='accept-cookies']",
                "//*[@id='cookie-accept']",
                "//*[contains(@class, 'cookie-accept')]",
                "//*[contains(@class, 'accept-cookies')]",
            ]
            for sel in accept_selectors:
                try:
                    btn = driver.find_element(By.XPATH, sel)
                    if btn.is_displayed():
                        btn.click()
                        _time.sleep(1)
                        break
                except Exception:
                    continue
        except Exception:
            pass  # تجاهل أخطاء قبول الكوكيز
        await txt.edit("🍪 جاري استخراج الكوكيز...")
        cookies = driver.get_cookies()
        driver.quit()
        if update_data_fn:
            update_data_fn(chat_id, "cache_cookies", cookies)
        with open(fname, "w", encoding="utf-8") as f:
            import json as _json
            f.write(_json.dumps(cookies, ensure_ascii=False, indent=2))
        await txt.edit("⬆️ جاري الرفع...")
        await message.reply_document(fname, caption=f"🍪 {len(cookies)} كوكي\n@Scraping_data_bot", quote=True)
        await asyncio.sleep(1)
        await txt.delete()
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)
    finally:
        if os.path.exists(fname): os.remove(fname)


# ─────────────────────── LocalStorage ─────────────────────────
async def extract_local_storage(query):
    message = query.message
    chat_id = message.chat.id
    fname   = f"localStorage-{chat_id}.txt"
    try:
        txt    = await message.reply_text("🌐 جاري تشغيل المتصفح...", quote=True)
        driver = await init_headless_browser(message.text)
        if not driver:
            return await txt.edit("❌ تعذّر تشغيل المتصفح.")
        await txt.edit("📦 جاري استخراج LocalStorage...")
        script = """
        var s = {};
        for (var i=0; i<localStorage.length; i++){
            var k=localStorage.key(i); s[k]=localStorage.getItem(k);
        } return s;
        """
        local_storage = driver.execute_script(script)
        driver.quit()
        with open(fname, "w", encoding="utf-8") as f:
            f.write(str(local_storage))
        await message.reply_document(fname, caption="📦 LocalStorage\n@Scraping_data_bot", quote=True)
        await asyncio.sleep(1)
        await txt.delete()
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)
    finally:
        if os.path.exists(fname): os.remove(fname)


# ─────────────────────── Screenshot ───────────────────────────
async def capture_screenshot(query):
    message = query.message
    chat_id = message.chat.id
    fname   = f"{chat_id}-screenshot.png"
    try:
        txt    = await message.reply_text("🌐 جاري تشغيل المتصفح...", quote=True)
        driver = await init_headless_browser(message.text)
        if not driver:
            return await txt.edit("❌ تعذّر تشغيل المتصفح. تأكد من تثبيت Chrome أو Firefox.")
        time.sleep(2)
        await txt.edit("📷 جاري التقاط الشاشة...")
        driver.save_screenshot(fname)
        driver.quit()
        await txt.edit("⬆️ جاري الرفع...")
        await message.reply_photo(fname, caption="📷 Screenshot\n@Scraping_data_bot")
        await asyncio.sleep(1)
        await txt.delete()
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)
    finally:
        if os.path.exists(fname): os.remove(fname)


# ─────────────────────── Screen Record ────────────────────────
async def record_screen(query, video_length=30, fps=10):
    message   = query.message
    chat_id   = message.chat.id
    shot_dir  = f"{chat_id}-screenshots"
    video_f   = f"{chat_id}-screen_record.mp4"
    try:
        txt    = await message.reply_text("🌐 جاري تشغيل المتصفح...", quote=True)
        driver = await init_headless_browser(message.text)
        if not driver:
            return await txt.edit("❌ تعذّر تشغيل المتصفح. تأكد من تثبيت Chrome أو Firefox.")
        time.sleep(2)
        scroll_height = driver.execute_script("return document.body.scrollHeight;")
        os.makedirs(shot_dir, exist_ok=True)
        await txt.edit(f"🎬 جاري التسجيل ({video_length} ثانية)...")
        for step in range(video_length):
            fraction = step / video_length
            driver.execute_script(f"window.scrollTo(0, {int(fraction * scroll_height)});")
            time.sleep(1 / fps)
            driver.save_screenshot(os.path.join(shot_dir, f"shot_{step:04d}.png"))
        driver.quit()
        await txt.edit("🎞️ جاري تحويل الصور إلى فيديو...")
        with imageio.get_writer(video_f, fps=fps) as writer:
            for step in range(video_length):
                img = imageio.imread(os.path.join(shot_dir, f"shot_{step:04d}.png"))
                for _ in range(3):
                    writer.append_data(img)
        time.sleep(1)
        await txt.edit("⬆️ جاري الرفع...")
        await message.reply_video(video_f, caption="🎬 Screen Recording\n@Scraping_data_bot")
        await asyncio.sleep(1)
        await txt.delete()
    except Exception as e:
        text, markup = error_markup(e)
        await message.reply_text(text, reply_markup=markup, quote=True)
    finally:
        if os.path.exists(shot_dir): shutil.rmtree(shot_dir)
        if os.path.exists(video_f): os.remove(video_f)
