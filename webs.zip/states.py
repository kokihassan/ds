# ============================================================
#  State Manager - لإدارة حالة المحادثة لكل مستخدم
# ============================================================

# state: None | "ai_chat" | "broadcast" | "edit_start" | "edit_contact" | "set_plan_user" | "ban_reason" | "add_admin"
_states = {}
_data   = {}

def set_state(user_id: int, state: str, data: dict = None):
    _states[user_id] = state
    _data[user_id]   = data or {}

def get_state(user_id: int) -> str:
    return _states.get(user_id)

def get_data(user_id: int) -> dict:
    return _data.get(user_id, {})

def clear_state(user_id: int):
    _states.pop(user_id, None)
    _data.pop(user_id, None)

def update_data(user_id: int, key: str, value):
    if user_id not in _data:
        _data[user_id] = {}
    _data[user_id][key] = value
