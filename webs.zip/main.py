# ============================================================
#  WebScrapper Bot - Main (Full Version - محدّث)
# ============================================================

import os, sys, logging
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[logging.FileHandler("bot.log"), logging.StreamHandler()]
)

import config
from config import START_TEXT, CONTACT_TEXT, ADMINS, PLANS, BOT_NAME
from utils import START_BUTTON, get_options_keyboard, get_plans_keyboard, get_plans_text
from database import (register_user, get_user, set_plan, can_use,
                      increment_usage, can_use_feature, get_all_users)
from admin import handle_admin_callback, admin_home_text, admin_home_kb, show_user_panel
from states import get_state, get_data, set_state, clear_state, update_data
from ai_assistant import ask_ai, quick_extract
from export_handler import get_export_keyboard
from scraper import (
    all_audio_scraping, all_images_scraping, all_links_scraping,
    all_paragraph_scraping, all_pdf_scraping, all_video_scraping,
    extract_cookies, extract_local_storage, html_data_scraping,
    raw_data_scraping, extract_metadata, capture_screenshot, record_screen,
)
from crawler import crawl_web

# helper: تمرير update_data لدوال السكرابينج
def _make_cache_fn(uid):
    def _fn(chat_id, key, value):
        update_data(uid, key, value)
    return _fn

bot_token = os.getenv("BOT_TOKEN")
api_id    = os.getenv("API_ID")
api_hash  = os.getenv("API_HASH")
CRAWL_LOG_CHANNEL = os.getenv("CRAWL_LOG_CHANNEL", "")

app = Client("WebScrapperBot", bot_token=bot_token, api_id=int(api_id), api_hash=api_hash)

# ─── حالات انتظار الرد من الأدمن ─────────────────────────────
ADMIN_EDIT_STATES = {
    "edit_start":            lambda txt: setattr(config, "START_TEXT", txt),
    "edit_contact":          lambda txt: setattr(config, "CONTACT_TEXT", txt),
    "edit_botname":          lambda txt: setattr(config, "BOT_NAME", txt),
    "edit_help":             lambda txt: setattr(config, "HELP_TEXT", txt),
    "edit_maintenance_msg":  lambda txt: setattr(config, "MAINTENANCE_MSG", txt),
    "set_banner":            lambda txt: setattr(config, "CUSTOM_BANNER", txt),
}


# ══════════════════════════════════════════════════════════════
#  /start
# ══════════════════════════════════════════════════════════════
@app.on_message(filters.command("start") & filters.private)
async def start(_, message: Message):
    uid  = message.from_user.id
    user = message.from_user
    register_user(uid, user.username or "")
    clear_state(uid)

    # وضع الصيانة
    if config.MAINTENANCE_MODE and uid not in config.ADMINS:
        return await message.reply_text(config.MAINTENANCE_MSG, quote=True)

    # فحص كود ترقية من /start PROMO_CODE
    args = message.text.split()
    if len(args) > 1:
        await handle_promo_code(message, uid, args[1])
        return

    text = config.START_TEXT
    if getattr(config, "CUSTOM_BANNER", ""):
        text += f"\n\n📣 **{config.CUSTOM_BANNER}**"

    await message.reply_text(
        text, disable_web_page_preview=True,
        quote=True, reply_markup=START_BUTTON
    )


async def handle_promo_code(message, uid, code):
    """معالجة أكواد الترقية"""
    import sqlite3
    conn = sqlite3.connect("subscriptions.db")
    try:
        row = conn.execute(
            "SELECT plan, days, max_uses, used_count FROM promo_codes WHERE code=?", (code,)
        ).fetchone()
        if not row:
            await message.reply_text(
                config.START_TEXT + "\n\n❌ الكود غير صحيح أو منتهي.",
                reply_markup=START_BUTTON, quote=True
            )
        elif row[3] >= row[2]:
            await message.reply_text(
                config.START_TEXT + "\n\n❌ انتهت استخدامات هذا الكود.",
                reply_markup=START_BUTTON, quote=True
            )
        else:
            plan, days = row[0], row[1]
            set_plan(uid, plan, days)
            conn.execute("UPDATE promo_codes SET used_count=used_count+1 WHERE code=?", (code,))
            conn.commit()
            plan_name = config.PLANS.get(plan, {}).get("name", plan)
            await message.reply_text(
                f"🎉 **تم تفعيل الكود بنجاح!**\n\n"
                f"📦 الباقة: **{plan_name}**\n"
                f"📅 المدة: **{days} يوم**\n\n" + config.START_TEXT,
                reply_markup=START_BUTTON, quote=True
            )
    except Exception as e:
        await message.reply_text(config.START_TEXT, reply_markup=START_BUTTON, quote=True)
    finally:
        conn.close()


# ══════════════════════════════════════════════════════════════
#  /admin
# ══════════════════════════════════════════════════════════════
@app.on_message(filters.command("admin") & filters.private & filters.user(ADMINS))
async def admin_cmd(_, message: Message):
    clear_state(message.from_user.id)
    await message.reply_text(admin_home_text(), reply_markup=admin_home_kb(), quote=True)


# ══════════════════════════════════════════════════════════════
#  /plans  /contact  /myplan  /help  /ai  /redeem
# ══════════════════════════════════════════════════════════════
@app.on_message(filters.command("plans") & filters.private)
async def plans_cmd(_, message: Message):
    await message.reply_text(get_plans_text(), reply_markup=get_plans_keyboard(), quote=True)


@app.on_message(filters.command("contact") & filters.private)
async def contact_cmd(_, message: Message):
    await message.reply_text(config.CONTACT_TEXT, quote=True)


@app.on_message(filters.command("myplan") & filters.private)
async def myplan_cmd(_, message: Message):
    uid  = message.from_user.id
    register_user(uid, message.from_user.username or "")
    user = get_user(uid)
    if not user:
        return await message.reply_text("⚠️ حدث خطأ، حاول مرة أخرى.")
    plan     = PLANS.get(user["plan"], PLANS["free"])
    limit    = plan["limit"]
    lim_txt  = "غير محدود ♾️" if limit == -1 else f"{user['daily_count']}/{limit} طلب اليوم"
    expiry   = user["expiry"] or "مستمر"
    ai_model = config.PLAN_AI_MODELS.get(user["plan"], "groq")
    exports  = ", ".join(plan.get("export_formats", []))
    await message.reply_text(
        f"📊 **حسابك:**\n\n"
        f"📦 الباقة: **{plan['name']}**\n"
        f"📅 تنتهي: `{expiry}`\n"
        f"📈 الاستخدام: {lim_txt}\n"
        f"🤖 موديل AI: **{ai_model}**\n"
        f"📤 صيغ التصدير: {exports}\n\n"
        f"لتغيير باقتك: /plans",
        quote=True
    )


@app.on_message(filters.command("help") & filters.private)
async def help_cmd(_, message: Message):
    await message.reply_text(
        f"🆘 **مساعدة {config.BOT_NAME}**\n━━━━━━━━━━━━━━━\n\n"
        "**الأوامر المتاحة:**\n"
        "• أرسل أي رابط → اختر العملية\n"
        "• /ai → مساعد ذكاء اصطناعي\n"
        "• /plans → الباقات المتاحة\n"
        "• /myplan → معلومات حسابك\n"
        "• /redeem → استخدام كود ترقية\n"
        "• /contact → التواصل\n\n"
        "**التصدير:**\n"
        "بعد أي استخراج، اختر صيغة التصدير: CSV, JSON, Excel, XML, Markdown أو TXT\n\n"
        "**المساعد الذكي:**\n"
        "أرسل رابط ثم اكتب ما تريد استخراجه بالكلام العادي!\n\n"
        "مثال:\n"
        "`https://example.com`\nثم: `استخرج كل الأسعار`",
        quote=True,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🤖 جرب المساعد الذكي", callback_data="cbai_intro")],
            [InlineKeyboardButton("📦 الباقات",            callback_data="cbplans")],
        ])
    )


@app.on_message(filters.command("redeem") & filters.private)
async def redeem_cmd(_, message: Message):
    uid = message.from_user.id
    register_user(uid, message.from_user.username or "")
    args = message.text.split()
    if len(args) > 1:
        await handle_promo_code(message, uid, args[1])
    else:
        set_state(uid, "enter_promo")
        await message.reply_text(
            "🎁 **استخدام كود ترقية**\n\nأرسل الكود الخاص بك:",
            quote=True,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="cbback")]])
        )


@app.on_message(filters.command("ai") & filters.private)
async def ai_cmd(_, message: Message):
    uid = message.from_user.id
    register_user(uid, message.from_user.username or "")
    set_state(uid, "ai_waiting_url")
    await message.reply_text(
        "🤖 **مساعد الذكاء الاصطناعي**\n━━━━━━━━━━━━━━━\n\n"
        "أرسل الرابط الذي تريد تحليله:",
        quote=True,
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("❌ إلغاء", callback_data="cbback")
        ]])
    )


# ══════════════════════════════════════════════════════════════
#  استقبال الروابط
# ══════════════════════════════════════════════════════════════
@app.on_message(
    (filters.regex(r"https?://") | filters.regex(r"www\."))
    & filters.private
)
async def handle_url(_, message: Message):
    uid  = message.from_user.id
    url  = message.text.strip()
    user = message.from_user
    register_user(uid, user.username or "")

    # وضع الصيانة
    if config.MAINTENANCE_MODE and uid not in config.ADMINS:
        return await message.reply_text(config.MAINTENANCE_MSG, quote=True)

    state = get_state(uid)

    if state == "ai_waiting_url":
        update_data(uid, "url", url)
        user_db  = get_user(uid)
        plan_key = user_db["plan"] if user_db else "free"
        set_state(uid, "ai_chat", {"url": url, "history": [], "plan": plan_key})
        ai_prov  = config.PLAN_AI_MODELS.get(plan_key, "groq")
        await message.reply_text(
            f"✅ **تم تحميل الصفحة!**\n`{url[:50]}...`\n\n"
            f"🤖 موديل AI: **{ai_prov}**\n\n"
            "الآن اسألني أي سؤال عن محتوى الصفحة:\n\n"
            "**أمثلة:**\n"
            "• استخرج كل الأسعار\n"
            "• ما هو موضوع الصفحة؟\n"
            "• استخرج بيانات التواصل\n"
            "• لخّص الصفحة\n"
            "• ابحث عن كلمة معينة",
            quote=True,
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("💰 أسعار",    callback_data="ai_quick_prices"),
                    InlineKeyboardButton("📞 تواصل",    callback_data="ai_quick_contacts"),
                    InlineKeyboardButton("📰 ملخص",     callback_data="ai_quick_summary"),
                ],
                [
                    InlineKeyboardButton("🛍️ منتجات",  callback_data="ai_quick_products"),
                    InlineKeyboardButton("📧 إيميلات", callback_data="ai_quick_emails"),
                    InlineKeyboardButton("📱 سوشيال",  callback_data="ai_quick_social"),
                ],
                [InlineKeyboardButton("❌ إنهاء المحادثة", callback_data="ai_end")],
            ])
        )
        return

    allowed, reason = can_use(uid)
    if not allowed:
        return await message.reply_text(f"🚫 {reason}", quote=True)

    user_db  = get_user(uid)
    plan_key = user_db["plan"] if user_db else "free"
    allowed_features = PLANS.get(plan_key, PLANS["free"])["allowed_features"]

    update_data(uid, "last_url", url)
    update_data(uid, "plan", plan_key)

    await message.reply_text(
        f"🔍 **اختر العملية:**\n`{url[:50]}...`" if len(url) > 50 else "🔍 **اختر العملية:**",
        reply_markup=get_options_keyboard(allowed_features),
        quote=True,
        disable_web_page_preview=True
    )


# ══════════════════════════════════════════════════════════════
#  استقبال الرسائل النصية العادية
# ══════════════════════════════════════════════════════════════
@app.on_message(filters.text & filters.private & ~filters.command(
    ["start","admin","plans","contact","myplan","help","ai","redeem"]
))
async def handle_text(_, message: Message):
    uid   = message.from_user.id
    text  = message.text.strip()
    state = get_state(uid)
    data  = get_data(uid)

    # ── AI Chat ─────────────────────────────────────────────
    if state == "ai_chat":
        url      = data.get("url", "")
        plan_key = data.get("plan", "free")
        if not url:
            clear_state(uid)
            return await message.reply_text("⚠️ انتهت الجلسة، أرسل رابطاً جديداً")
        thinking = await message.reply_text("🤔 جاري التحليل...", quote=True)
        history  = data.get("history", [])
        answer   = await ask_ai(url, text, history, plan_key)
        history.append({"role": "user",      "content": text})
        history.append({"role": "assistant", "content": answer})
        if len(history) > 20:
            history = history[-20:]
        update_data(uid, "history", history)
        await thinking.delete()
        await message.reply_text(
            f"🤖 {answer}",
            quote=True,
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("💰 أسعار",   callback_data="ai_quick_prices"),
                    InlineKeyboardButton("📞 تواصل",   callback_data="ai_quick_contacts"),
                    InlineKeyboardButton("📰 ملخص",    callback_data="ai_quick_summary"),
                ],
                [InlineKeyboardButton("❌ إنهاء المحادثة", callback_data="ai_end")],
            ])
        )
        return

    # ── كود ترقية ─────────────────────────────────────────────
    if state == "enter_promo":
        clear_state(uid)
        await handle_promo_code(message, uid, text)
        return

    # ── تعديل النصوص (أدمن) ─────────────────────────────────
    if state in ADMIN_EDIT_STATES and uid in ADMINS:
        ADMIN_EDIT_STATES[state](text)
        clear_state(uid)
        await message.reply_text(
            "✅ تم التحديث بنجاح!",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 لوحة التحكم", callback_data="adm_home")
            ]])
        )
        return

    # ── تغيير حد الطلبات (أدمن) ─────────────────────────────
    if state == "set_ratelimit" and uid in ADMINS:
        try:
            config.RATE_LIMIT_SECONDS = int(text)
            clear_state(uid)
            await message.reply_text(
                f"✅ تم تغيير التأخير إلى **{text} ثانية**",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع", callback_data="adm_rate_limits")]])
            )
        except:
            await message.reply_text("❌ أرسل رقماً صحيحاً")
        return

    # ── تغيير أقصى حجم (أدمن) ─────────────────────────────
    if state == "set_maxsize" and uid in ADMINS:
        try:
            config.MAX_FILE_SIZE_MB = int(text)
            clear_state(uid)
            await message.reply_text(
                f"✅ تم تغيير أقصى حجم إلى **{text} MB**",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع", callback_data="adm_rate_limits")]])
            )
        except:
            await message.reply_text("❌ أرسل رقماً صحيحاً")
        return

    # ── إنشاء كود ترقية (أدمن) ─────────────────────────────
    if state == "create_promo" and uid in ADMINS:
        parts = text.strip().split("|")
        if len(parts) != 3:
            return await message.reply_text("❌ الصيغة: `كود|أيام|أقصى_استخدام`\nمثال: `SUMMER2025|30|5`")
        code, days_str, max_uses_str = parts
        import sqlite3
        plan_key = data.get("plan", "pro")
        try:
            days     = int(days_str)
            max_uses = int(max_uses_str)
            conn = sqlite3.connect("subscriptions.db")
            conn.execute(
                "INSERT OR REPLACE INTO promo_codes (code, plan, days, max_uses) VALUES (?,?,?,?)",
                (code.strip(), plan_key, days, max_uses)
            )
            conn.commit()
            conn.close()
            clear_state(uid)
            plan_name = config.PLANS.get(plan_key, {}).get("name", plan_key)
            await message.reply_text(
                f"✅ **تم إنشاء الكود!**\n\n"
                f"🎁 الكود: `{code.strip()}`\n"
                f"📦 الباقة: {plan_name}\n"
                f"📅 المدة: {days} يوم\n"
                f"🔢 أقصى استخدام: {max_uses}",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 الأكواد", callback_data="adm_promo_codes")]])
            )
        except Exception as e:
            await message.reply_text(f"❌ خطأ: {e}")
        return

    # ── برودكاست ────────────────────────────────────────────
    if state == "broadcast" and uid in ADMINS:
        group = data.get("group", "all")
        users = get_all_users()
        if group != "all":
            users = [u for u in users if u[2] == group]
        clear_state(uid)
        sent, failed = 0, 0
        status_msg = await message.reply_text(f"📢 جاري الإرسال لـ {len(users)} مستخدم...")
        for u in users:
            try:
                await app.send_message(u[0], text)
                sent += 1
            except:
                failed += 1
        await status_msg.edit_text(
            f"✅ **تم الإرسال!**\n\n✉️ نجح: **{sent}**\n❌ فشل: **{failed}**",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 لوحة التحكم", callback_data="adm_home")]])
        )
        return

    # ── حظر برسبب ───────────────────────────────────────────
    if state == "ban_reason" and uid in ADMINS:
        target = data.get("target")
        reason = text if text != "-" else "محظور من الأدمن"
        from database import ban_user
        ban_user(target, reason)
        clear_state(uid)
        await message.reply_text(
            f"🚫 تم حظر `{target}`\nالسبب: {reason}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 لوحة التحكم", callback_data="adm_home")]])
        )
        return

    # ── إرسال رسالة لمستخدم ─────────────────────────────────
    if state == "send_msg_user" and uid in ADMINS:
        target = data.get("target")
        clear_state(uid)
        try:
            await app.send_message(target, f"💬 **رسالة من الإدارة:**\n\n{text}")
            await message.reply_text("✅ تم إرسال الرسالة")
        except:
            await message.reply_text("❌ فشل الإرسال")
        return

    # ── إضافة أدمن ──────────────────────────────────────────
    if state == "add_admin" and uid in ADMINS:
        try:
            new_id = int(text)
            if new_id not in config.ADMINS:
                config.ADMINS.append(new_id)
            clear_state(uid)
            await message.reply_text(
                f"✅ تم إضافة `{new_id}` كأدمن",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 لوحة التحكم", callback_data="adm_home")]])
            )
        except ValueError:
            await message.reply_text("❌ أرسل رقم ID صحيح")
        return

    # ── رسالة ID لإرسال ─────────────────────────────────────
    if state == "msg_by_id" and uid in ADMINS:
        try:
            target = int(text)
            set_state(uid, "send_msg_user", {"target": target})
            await message.reply_text(
                f"💬 أرسل الرسالة للمستخدم `{target}`:",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="adm_support")]])
            )
        except ValueError:
            await message.reply_text("❌ أرسل رقم ID صحيح")
        return

    # ── بحث مستخدم ──────────────────────────────────────────
    if state == "search_user" and uid in ADMINS:
        query = text.replace("@", "")
        users = get_all_users()
        found = None
        try:
            found = next((u for u in users if u[0] == int(query)), None)
        except:
            found = next((u for u in users if u[1] == query), None)
        clear_state(uid)
        if found:
            await show_user_panel(message, found[0])
        else:
            await message.reply_text(
                f"❌ لم يتم العثور على المستخدم: `{query}`",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع", callback_data="adm_users_0")]])
            )
        return


# ══════════════════════════════════════════════════════════════
#  Callbacks
# ══════════════════════════════════════════════════════════════
@app.on_callback_query()
async def cb_data(bot: Client, update):
    uid  = update.from_user.id
    data = update.data

    # ── لوحة الأدمن ──────────────────────────────────────────
    if data.startswith("adm_"):
        return await handle_admin_callback(bot, update, data)

    # ── AI Callbacks ─────────────────────────────────────────
    if data == "cbai_intro":
        set_state(uid, "ai_waiting_url")
        await update.message.edit_text(
            "🤖 **مساعد الذكاء الاصطناعي**\n\nأرسل الرابط الذي تريد تحليله:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="cbback")]])
        )
        return

    if data == "ai_end":
        clear_state(uid)
        await update.message.edit_text(
            "✅ انتهت جلسة AI\n\nأرسل رابطاً جديداً أو /start",
            reply_markup=START_BUTTON
        )
        return

    if data.startswith("ai_quick_"):
        extract_type = data.replace("ai_quick_", "")
        state_data   = get_data(uid)
        url          = state_data.get("url", "")
        plan_key     = state_data.get("plan", "free")
        if not url:
            return await update.answer("❌ لم يتم تحديد رابط", show_alert=True)
        await update.answer("🤔 جاري التحليل...")
        thinking = await update.message.reply_text("🤖 جاري الاستخراج...")
        result   = await quick_extract(url, extract_type, plan_key)
        await thinking.edit_text(
            f"🤖 **{extract_type}:**\n\n{result}",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("💰 أسعار",   callback_data="ai_quick_prices"),
                    InlineKeyboardButton("📞 تواصل",   callback_data="ai_quick_contacts"),
                    InlineKeyboardButton("📰 ملخص",    callback_data="ai_quick_summary"),
                ],
                [
                    InlineKeyboardButton("🛍️ منتجات", callback_data="ai_quick_products"),
                    InlineKeyboardButton("📧 إيميلات",callback_data="ai_quick_emails"),
                    InlineKeyboardButton("📱 سوشيال",  callback_data="ai_quick_social"),
                ],
                [InlineKeyboardButton("❌ إنهاء", callback_data="ai_end")],
            ])
        )
        return

    # ── باقات ────────────────────────────────────────────────
    if data == "cbplans":
        await update.message.edit_text(get_plans_text(), reply_markup=get_plans_keyboard())
        return

    if data.startswith("cbplan_"):
        plan_key = data.split("_", 1)[1]
        plan     = PLANS.get(plan_key)
        if not plan:
            return await update.answer("❌ الباقة غير موجودة")
        price_txt = "مجاني" if plan["price"] == 0 else f"${plan['price']}/{plan['period']}"
        exports   = ", ".join(plan.get("export_formats", []))
        ai_mod    = config.PLAN_AI_MODELS.get(plan_key, "groq")
        await update.message.reply_text(
            f"📦 **{plan['name']}** — {price_txt}\n"
            f"🤖 موديل AI: **{ai_mod}**\n"
            f"📤 صيغ التصدير: {exports}\n\n"
            f"للاشتراك تواصل:\n{config.CONTACT_TEXT}",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("📞 تواصل الآن", callback_data="cbcontact")
            ]])
        )
        return

    if data == "cbcontact":
        await update.message.reply_text(config.CONTACT_TEXT)
        return

    if data == "cbmyplan":
        user     = get_user(uid)
        plan_key = user["plan"] if user else "free"
        plan     = PLANS.get(plan_key, PLANS["free"])
        limit    = plan["limit"]
        lim_txt  = "غير محدود ♾️" if limit == -1 else f"{user['daily_count']}/{limit}"
        exports  = ", ".join(plan.get("export_formats", []))
        await update.message.reply_text(
            f"📊 **باقتك:** {plan['name']}\n"
            f"📅 **تنتهي:** {user['expiry'] or 'مستمر'}\n"
            f"📈 **الاستخدام:** {lim_txt}\n"
            f"🤖 **موديل AI:** {config.PLAN_AI_MODELS.get(plan_key,'groq')}\n"
            f"📤 **التصدير:** {exports}\n\n"
            f"لتغيير الباقة: /plans"
        )
        return

    if data == "cbback":
        clear_state(uid)
        await update.message.edit_text(
            config.START_TEXT, disable_web_page_preview=True, reply_markup=START_BUTTON
        )
        return

    # ══ التصدير ══════════════════════════════════════════════
    if data.startswith("cbexport_"):
        parts    = data.split("_", 2)
        data_key = parts[1]
        fmt      = parts[2]
        state_d  = get_data(uid)
        url      = state_d.get("last_url", "")
        plan_key = state_d.get("plan", "free")

        cached = state_d.get(f"cache_{data_key}")
        if not cached:
            return await update.answer("❌ البيانات انتهت، أعد الطلب", show_alert=True)

        await update.answer("⏳ جاري التصدير...")
        try:
            from export_handler import (export_links, export_paragraphs,
                                         export_metadata, export_cookies,
                                         export_raw_text)

            if data_key == "links":
                filename, content, mime = export_links(cached, fmt, url)
            elif data_key == "paragraphs":
                filename, content, mime = export_paragraphs(cached, fmt, url)
            elif data_key == "metadata":
                # cached هنا dict وليس list
                filename, content, mime = export_metadata(cached, fmt, url)
            elif data_key == "cookies":
                filename, content, mime = export_cookies(cached, fmt, url)
            elif data_key == "rawdata":
                # cached هنا نص خام
                raw_str = cached if isinstance(cached, str) else str(cached)
                filename, content, mime = export_raw_text(raw_str, fmt, url)
            else:
                from export_handler import _export_list
                if isinstance(cached, list):
                    filename, content, mime = _export_list(cached, fmt, data_key, url)
                else:
                    filename, content, mime = export_raw_text(str(cached), fmt, url)

            with open(filename, "wb") as f:
                f.write(content)
            await bot.send_document(
                uid, filename,
                caption=f"📤 **{data_key.upper()}** — {fmt.upper()}\n🔗 {url[:60]}"
            )
            import os; os.remove(filename)

            if config.LOG_REQUESTS:
                _log_export(uid, data_key, fmt)

        except Exception as e:
            await update.message.reply_text(f"❌ فشل التصدير: {e}")
        return

    # ── عمليات السحب ─────────────────────────────────────────
    allowed, reason = can_use(uid)
    if not allowed:
        return await update.answer(reason, show_alert=True)

    # وضع الصيانة
    if config.MAINTENANCE_MODE and uid not in config.ADMINS:
        return await update.answer(config.MAINTENANCE_MSG, show_alert=True)

    feature_map = {
        "cbrdata":         ("rawData",       raw_data_scraping,      None),
        "cbhtmldata":      ("htmlData",      html_data_scraping,     None),
        "cballlinks":      ("allLinks",      all_links_scraping,     None),
        "cballparagraphs": ("allParagraphs", all_paragraph_scraping, None),
        "cballimages":     ("allImages",     all_images_scraping,    bot),
        "cballaudio":      ("allAudio",      all_audio_scraping,     bot),
        "cballvideo":      ("allVideo",      all_video_scraping,     bot),
        "cballpdf":        ("allPdf",        all_pdf_scraping,       None),
        "cbcookies":       ("cookies",       extract_cookies,        None),
        "cblocalstorage":  ("localStorage",  extract_local_storage,  None),
        "cbmetadata":      ("metadata",      extract_metadata,       None),
        "cbscreenshot":    ("screenshot",    capture_screenshot,     None),
        "cbscreenrecord":  ("screenRecord",  record_screen,          None),
        "cbcrawl":         ("crawlWeb",      None,                   bot),
    }

    if data in feature_map:
        feature_key, func, extra = feature_map[data]
        if not can_use_feature(uid, feature_key):
            return await update.answer(
                "🔒 هذه الميزة غير متاحة في باقتك.\nرفّع الباقة عبر /plans",
                show_alert=True
            )
        increment_usage(uid)
        state_d  = get_data(uid)
        url      = state_d.get("last_url", "")
        plan_key = state_d.get("plan", "free")
        cache_fn = _make_cache_fn(uid)

        if data == "cbcrawl":
            if CRAWL_LOG_CHANNEL:
                await crawl_web(bot, update)
            else:
                await update.message.reply("⚠️ يجب ضبط CRAWL_LOG_CHANNEL في .env")
        elif extra:
            result = await func(extra, update)
        elif data in ("cbrdata", "cbhtmldata", "cballlinks", "cballparagraphs"):
            result = await func(update, update_data_fn=cache_fn)
        elif data in ("cbcookies",):
            result = await func(update, update_data_fn=cache_fn)
        elif data == "cbmetadata":
            result = await func(update, update_data_fn=cache_fn)
        elif data == "cblocalstorage":
            result = await func(update)
        else:
            result = await func(update)

        # عرض خيارات التصدير بعد الاستخراج (للبيانات النصية فقط)
        export_supported = ["cbrdata", "cbhtmldata", "cballlinks", "cballparagraphs",
                            "cbcookies", "cblocalstorage", "cbmetadata"]
        if data in export_supported and url:
            data_key_map = {
                "cbrdata":         "rawdata",
                "cbhtmldata":      "rawdata",
                "cballlinks":      "links",
                "cballparagraphs": "paragraphs",
                "cbcookies":       "cookies",
                "cblocalstorage":  "cookies",
                "cbmetadata":      "metadata",
            }
            dk = data_key_map.get(data, "data")
            try:
                await update.message.reply_text(
                    "📤 **اختر صيغة التصدير:**",
                    reply_markup=get_export_keyboard(dk, plan_key)
                )
            except:
                pass

    elif data == "cdstoptrasmission":
        bot.stop_transmission()


def _log_export(user_id: int, data_type: str, fmt: str):
    """تسجيل عملية تصدير"""
    import sqlite3
    from datetime import datetime
    today = datetime.now().strftime("%Y-%m-%d")
    try:
        conn = sqlite3.connect("subscriptions.db")
        conn.execute("""CREATE TABLE IF NOT EXISTS export_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER, data_type TEXT, format TEXT, date TEXT
        )""")
        conn.execute("INSERT INTO export_logs (user_id, data_type, format, date) VALUES (?,?,?,?)",
                     (user_id, data_type, fmt, today))
        conn.commit()
        conn.close()
    except:
        pass


app.run(print("✅ Bot is running..."))
