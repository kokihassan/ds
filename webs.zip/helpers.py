# ============================================================
#  Helpers - مع قبول الكوكيز + بروكسي + متصفح محسّن
# ============================================================

import shutil, requests, math, os, time, logging
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import FINISHED_PROGRESS_STR, UN_FINISHED_PROGRESS_STR
from proxy_manager import requests_get, get_proxy

logger = logging.getLogger(__name__)

# Headers شاملة تقبل الكوكيز
BASE_HEADERS = {
    "User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Cache-Control":   "no-cache",
    "Cookie":          "cookieconsent_status=allow; gdpr=1; cookie_consent=accepted; CONSENT=YES+",
    "Sec-Fetch-Dest":  "document",
    "Sec-Fetch-Mode":  "navigate",
    "Sec-Fetch-Site":  "none",
}


async def progress_bar(current, total):
    if total == 0:
        return FINISHED_PROGRESS_STR * 10, "100.00"
    pct    = current / total
    done   = int(pct * 10)
    bar    = FINISHED_PROGRESS_STR * done + UN_FINISHED_PROGRESS_STR * (10 - done)
    return bar, f"{pct * 100:.2f}"


async def progress_for_pyrogram(current, total, ud_type, message, start):
    markup = InlineKeyboardMarkup([[InlineKeyboardButton("🚫 إلغاء", callback_data="cdstoptrasmission")]])
    now  = time.time()
    diff = now - start
    if round(diff % 10.00) == 0 or current == total:
        pct   = current * 100 / total
        speed = current / diff if diff > 0 else 0
        eta   = round((total - current) / speed) * 1000 if speed > 0 else 0
        bar   = "[{0}{1}]\n📊 **{2}%**\n".format(
            "■" * math.floor(pct / 5), "□" * (20 - math.floor(pct / 5)), round(pct, 2)
        )
        tmp = bar + "✅ **تم:** {0}\n📁 **الحجم:** {1}\n🚀 **السرعة:** {2}/s\n⌚ **المتبقي:** {3}".format(
            humanbytes(current), humanbytes(total), humanbytes(speed), TimeFormatter(eta) or "0 s"
        )
        try:
            await message.edit(text=f"{ud_type}\n{tmp}", reply_markup=markup)
        except:
            pass


def humanbytes(size):
    if not size: return "0 B"
    power, n, labels = 2**10, 0, {0:"B",1:"KiB",2:"MiB",3:"GiB",4:"TiB"}
    while size > power and n < 4:
        size /= power; n += 1
    return f"{size:.2f} {labels[n]}"


def TimeFormatter(ms: int) -> str:
    s, _  = divmod(int(ms), 1000)
    m, s  = divmod(s, 60)
    h, m  = divmod(m, 60)
    d, h  = divmod(h, 24)
    parts = []
    if d: parts.append(f"{d}d")
    if h: parts.append(f"{h}h")
    if m: parts.append(f"{m}m")
    if s: parts.append(f"{s}s")
    return " ".join(parts)


# ══════════════════════════════════════════════
#  تحميل الصور
# ══════════════════════════════════════════════

async def download_image(base_url, image_url, idx):
    try:
        if not image_url.startswith(("http:", "https:")):
            from urllib.parse import urljoin
            image_url = urljoin(base_url, image_url)
        headers = {**BASE_HEADERS, "Referer": base_url}
        r = requests_get(image_url, headers=headers, timeout=15, stream=True)
        fname = f"_tmp_img_{idx}.jpg"
        with open(fname, "wb") as f:
            shutil.copyfileobj(r.raw, f)
        with open(fname, "rb") as f:
            data = f.read()
        os.remove(fname)
        return data
    except Exception as e:
        logger.warning(f"[download_image] {e}")
        return None


async def download_media(base_url, media_url, idx, media_type):
    try:
        if not media_url.startswith(("http:", "https:")):
            from urllib.parse import urljoin
            media_url = urljoin(base_url, media_url)
        headers = {**BASE_HEADERS, "Referer": base_url}
        with requests_get(media_url, headers=headers, timeout=30, stream=True) as r:
            filename = os.path.basename(media_url.split("?")[0]) or f"{media_type}{idx}"
            local_fn = f"_tmp_{media_type}_{idx}_{filename}"
            with open(local_fn, "wb") as f:
                shutil.copyfileobj(r.raw, f)
            with open(local_fn, "rb") as f:
                data = f.read()
            os.remove(local_fn)
            return data, filename
    except Exception as e:
        logger.warning(f"[download_media] {e}")
        return None


async def download_pdf(base_url, pdf_url, idx, media_type):
    try:
        if not pdf_url.startswith(("http:", "https:")):
            from urllib.parse import urljoin
            pdf_url = urljoin(base_url, pdf_url)
        headers = {**BASE_HEADERS, "Referer": base_url}
        r = requests_get(pdf_url, headers=headers, timeout=30, stream=True)
        fname = f"_tmp_pdf_{idx}.pdf"
        with open(fname, "wb") as f:
            for chunk in r.iter_content(8192):
                f.write(chunk)
        with open(fname, "rb") as f:
            data = f.read()
        os.remove(fname)
        return data
    except Exception as e:
        logger.warning(f"[download_pdf] {e}")
        return None


# ══════════════════════════════════════════════
#  المتصفح - Chrome أولاً ثم Firefox مع قبول الكوكيز
# ══════════════════════════════════════════════

async def init_headless_browser(url: str, accept_cookies: bool = True):
    proxy = get_proxy()

    # Chrome
    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        from selenium.webdriver.chrome.service import Service
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.common.by import By

        opts = Options()
        opts.add_argument("--headless=new")
        opts.add_argument("--no-sandbox")
        opts.add_argument("--disable-dev-shm-usage")
        opts.add_argument("--disable-gpu")
        opts.add_argument("--window-size=1920,1080")
        opts.add_argument("--disable-blink-features=AutomationControlled")
        opts.add_experimental_option("excludeSwitches", ["enable-automation"])
        opts.add_experimental_option("useAutomationExtension", False)
        opts.add_argument(f"--user-agent={BASE_HEADERS['User-Agent']}")

        # إضافة بروكسي للمتصفح
        if proxy:
            proxy_url = proxy.get("http", "").replace("http://", "").replace("https://", "")
            opts.add_argument(f"--proxy-server={proxy_url}")

        driver = webdriver.Chrome(options=opts)

        # إخفاء علامات الأتمتة
        driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
            "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
        })

        driver.get(url)
        time.sleep(2)

        if accept_cookies:
            _accept_cookies_selenium(driver)

        return driver
    except Exception as e_chrome:
        logger.warning(f"[Chrome] {e_chrome}")

    # Firefox كبديل
    try:
        from selenium import webdriver
        from selenium.webdriver.firefox.options import Options

        opts = Options()
        opts.add_argument("--headless")
        if proxy:
            proxy_host = proxy.get("http", "").split("://")[-1].split(":")[0]
            proxy_port = proxy.get("http", "").split(":")[-1]
            opts.set_preference("network.proxy.type", 1)
            opts.set_preference("network.proxy.http", proxy_host)
            opts.set_preference("network.proxy.http_port", int(proxy_port) if proxy_port.isdigit() else 8080)

        driver = webdriver.Firefox(options=opts)
        driver.get(url)
        time.sleep(2)
        if accept_cookies:
            _accept_cookies_selenium(driver)
        return driver
    except Exception as e_ff:
        logger.warning(f"[Firefox] {e_ff}")

    return None


def _accept_cookies_selenium(driver):
    """يقبل الكوكيز تلقائياً بجميع الطرق"""
    from selenium.webdriver.common.by import By

    # 1. ضبط الكوكيز مباشرة
    for name, val in [
        ("cookieconsent_status", "allow"),
        ("gdpr",                 "1"),
        ("cookie_consent",       "accepted"),
        ("CONSENT",              "YES+"),
        ("euconsent",            "1"),
    ]:
        try:
            driver.add_cookie({"name": name, "value": val})
        except:
            pass

    # 2. البحث عن أزرار القبول والضغط عليها
    accept_texts = [
        "accept", "agree", "allow", "ok", "got it", "i agree",
        "accept all", "accept cookies", "allow all", "قبول", "موافق",
        "أوافق", "قبول الكل", "السماح", "accept & continue",
    ]
    selectors = [
        "button", "a", "[role='button']",
        ".cookie-accept", ".accept-cookies", "#accept-cookies",
        ".gdpr-accept", "[data-consent='accept']",
        ".CybotCookiebotDialogBodyButton", "#CybotCookiebotDialogBodyButtonAccept",
        ".cc-btn.cc-allow", ".cc-accept",
    ]

    for selector in selectors:
        try:
            elements = driver.find_elements(By.CSS_SELECTOR, selector)
            for el in elements:
                text = (el.text or el.get_attribute("value") or "").lower().strip()
                if any(t in text for t in accept_texts):
                    driver.execute_script("arguments[0].click();", el)
                    time.sleep(0.5)
                    break
        except:
            pass

    # 3. JavaScript لقبول الكوكيز
    try:
        driver.execute_script("""
            // Cookiebot
            if (window.Cookiebot) Cookiebot.accept();
            // OneTrust
            if (window.OneTrust) OneTrust.AllowAll();
            // Generic
            document.querySelectorAll('[id*=cookie],[class*=cookie],[id*=consent],[class*=consent]').forEach(el => {
                el.querySelectorAll('button').forEach(btn => {
                    if (/accept|allow|agree|ok/i.test(btn.textContent)) btn.click();
                });
            });
        """)
        time.sleep(0.5)
    except:
        pass
